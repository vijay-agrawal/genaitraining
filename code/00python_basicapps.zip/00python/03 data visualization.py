# File: 00python/data_visualization.py
# Enhanced script for meaningful loan approval data visualization

import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

def clean_income(value):
    """Clean income values handling mixed formats"""
    if pd.isna(value) or value == 'nan' or value == 'n/a':
        return np.nan
    
    value = str(value).lower().strip()
    
    if 'unemployed' in value or value == '' or value == 'n/a':
        return np.nan
    
    if 'rs' in value and 'lacs' in value:
        try:
            import re
            match = re.search(r'(\d+(?:\.\d+)?)', value)
            if match:
                return float(match.group(1)) * 100000
        except:
            return np.nan
    
    try:
        return float(value)
    except:
        return np.nan

def clean_age(value):
    """Clean age values handling formats like '23yrs', '38yrs 1 months'"""
    if pd.isna(value) or value == 'nan' or value == 'n/a':
        return np.nan
    
    value = str(value).lower().strip()
    
    try:
        # Extract first number from strings like '23yrs' or '38yrs 1 months'
        import re
        match = re.search(r'(\d+)', value)
        if match:
            return int(match.group(1))
        return float(value)
    except:
        return np.nan

def main():
    # Define the path to the data file
    data_path = "00python/data/loanapproval_hist_data.csv"
    
    try:
        # Check if file exists
        if not os.path.exists(data_path):
            print(f"Error: File not found at {data_path}")
            return
        
        # Load the data
        print("Loading data for visualization...")
        df = pd.read_csv(data_path)
        
        # Remove ID column if it exists
        if 'ID' in df.columns:
            df = df.drop('ID', axis=1)
            print("ID column removed from analysis")
        
        # Clean the data
        print("Cleaning data...")
        df['Income_Clean'] = df['Income'].apply(clean_income)
        df['Age_Clean'] = df['Age'].apply(clean_age)
        
        # Create a figure with 3 subplots
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        fig.suptitle('Loan Approval Data Analysis - Key Insights', fontsize=16)
        
        # Plot 1: Loan Approval Rate by Education Level
        if 'Education' in df.columns and 'Loanapproved' in df.columns:
            education_clean = df[['Education', 'Loanapproved']].dropna()
            
            if len(education_clean) > 0:
                # Calculate approval rates by education
                approval_by_education = education_clean.groupby('Education')['Loanapproved'].agg(['mean', 'count']).reset_index()
                approval_by_education['approval_rate'] = approval_by_education['mean'] * 100
                
                # Create bar chart
                bars = axes[0, 0].bar(approval_by_education['Education'], approval_by_education['approval_rate'], 
                                    color=['lightblue', 'lightgreen', 'lightcoral'], alpha=0.8)
                axes[0, 0].set_title('Loan Approval Rate by Education Level', fontsize=14)
                axes[0, 0].set_xlabel('Education Level')
                axes[0, 0].set_ylabel('Approval Rate (%)')
                axes[0, 0].tick_params(axis='x', rotation=45)
                axes[0, 0].grid(True, alpha=0.3)
                
                # Add percentage labels on bars
                for bar, rate in zip(bars, approval_by_education['approval_rate']):
                    axes[0, 0].text(bar.get_x() + bar.get_width()/2, bar.get_height() + 1,
                                  f'{rate:.1f}%', ha='center', va='bottom', fontweight='bold')
        
        # Plot 2: Age vs Income Scatter Plot (colored by loan approval)
        age_income_data = df[['Age_Clean', 'Income_Clean', 'Loanapproved']].dropna()
        
        if len(age_income_data) > 0:
            # Separate approved and rejected loans
            approved = age_income_data[age_income_data['Loanapproved'] == 1]
            rejected = age_income_data[age_income_data['Loanapproved'] == 0]
            
            # Create scatter plot
            axes[0, 1].scatter(rejected['Age_Clean'], rejected['Income_Clean'], 
                             alpha=0.6, c='red', label='Loan Rejected', s=50)
            axes[0, 1].scatter(approved['Age_Clean'], approved['Income_Clean'], 
                             alpha=0.6, c='green', label='Loan Approved', s=50)
            
            axes[0, 1].set_title('Age vs Income (Loan Approval Status)', fontsize=14)
            axes[0, 1].set_xlabel('Age (years)')
            axes[0, 1].set_ylabel('Income')
            axes[0, 1].legend()
            axes[0, 1].grid(True, alpha=0.3)
        
        # Plot 3: Credit Card Average Spending vs Loan Approval
        if 'CCAvg' in df.columns and 'Loanapproved' in df.columns:
            cc_loan_data = df[['CCAvg', 'Loanapproved']].dropna()
            
            if len(cc_loan_data) > 0:
                # Create box plot
                approved_cc = cc_loan_data[cc_loan_data['Loanapproved'] == 1]['CCAvg']
                rejected_cc = cc_loan_data[cc_loan_data['Loanapproved'] == 0]['CCAvg']
                
                box_data = [rejected_cc, approved_cc]
                box_plot = axes[1, 0].boxplot(box_data, labels=['Rejected', 'Approved'], 
                                            patch_artist=True, notch=True)
                
                # Color the boxes
                colors = ['lightcoral', 'lightgreen']
                for patch, color in zip(box_plot['boxes'], colors):
                    patch.set_facecolor(color)
                    patch.set_alpha(0.7)
                
                axes[1, 0].set_title('Credit Card Average Spending\nby Loan Approval Status', fontsize=14)
                axes[1, 0].set_xlabel('Loan Status')
                axes[1, 0].set_ylabel('Average CC Spending')
                axes[1, 0].grid(True, alpha=0.3)
        
        # Plot 4: Family Size vs Loan Approval Rate
        if 'Family' in df.columns and 'Loanapproved' in df.columns:
            family_clean = df[['Family', 'Loanapproved']].dropna()
            
            if len(family_clean) > 0:
                # Calculate approval rates by family size
                family_approval = family_clean.groupby('Family')['Loanapproved'].agg(['mean', 'count']).reset_index()
                family_approval['approval_rate'] = family_approval['mean'] * 100
                
                # Create line plot
                axes[1, 1].plot(family_approval['Family'], family_approval['approval_rate'], 
                              marker='o', linewidth=2, markersize=8, color='blue')
                axes[1, 1].set_title('Loan Approval Rate by Family Size', fontsize=14)
                axes[1, 1].set_xlabel('Family Size')
                axes[1, 1].set_ylabel('Approval Rate (%)')
                axes[1, 1].grid(True, alpha=0.3)
                
                # Add data labels
                for x, y in zip(family_approval['Family'], family_approval['approval_rate']):
                    axes[1, 1].annotate(f'{y:.1f}%', (x, y), textcoords="offset points", 
                                      xytext=(0,10), ha='center', fontweight='bold')
        
        # Adjust layout to prevent overlapping
        plt.tight_layout()
        
        # Save the plot
        plt.savefig('00python/loan_data_insights.png', dpi=300, bbox_inches='tight')
        print("Charts saved as 'loan_data_insights.png'")
        
        # Show the plot
        plt.show()
        
        # Print detailed statistics
        print("\n" + "="*60)
        print("DETAILED DATA ANALYSIS")
        print("="*60)
        
        print(f"Dataset shape: {df.shape}")
        print(f"Valid income records: {df['Income_Clean'].notna().sum()} out of {len(df)}")
        print(f"Valid age records: {df['Age_Clean'].notna().sum()} out of {len(df)}")
        
        # Education analysis
        if 'Education' in df.columns and 'Loanapproved' in df.columns:
            education_stats = df.groupby('Education')['Loanapproved'].agg(['mean', 'count'])
            print(f"\n=== LOAN APPROVAL BY EDUCATION ===")
            for edu, row in education_stats.iterrows():
                print(f"{edu:15}: {row['mean']*100:5.1f}% approval rate ({row['count']} applicants)")
        
        # Income analysis
        if 'Income_Clean' in df.columns:
            income_data = df['Income_Clean'].dropna()
            print(f"\n=== INCOME STATISTICS ===")
            print(f"Mean Income: {income_data.mean():.2f}")
            print(f"Median Income: {income_data.median():.2f}")
            print(f"Income Range: {income_data.min():.2f} to {income_data.max():.2f}")
        
        # Overall approval rate
        if 'Loanapproved' in df.columns:
            overall_approval = df['Loanapproved'].mean() * 100
            print(f"\n=== OVERALL APPROVAL RATE ===")
            print(f"Overall loan approval rate: {overall_approval:.1f}%")
            print(f"Total applications: {len(df)}")
            print(f"Approved: {df['Loanapproved'].sum()}")
            print(f"Rejected: {len(df) - df['Loanapproved'].sum()}")
        
    except FileNotFoundError:
        print(f"Error: Could not find the file at {data_path}")
    except Exception as e:
        print(f"Error creating visualizations: {e}")

if __name__ == "__main__":
    main()