from sklearn.preprocessing import PolynomialFeatures

import numpy as np

# Log transform the heavily impacting feature (if it follows an exponential pattern)
df['Feature1_log'] = np.log1p(df['Feature1'])

# Generate polynomial features (if the relationship is non-linear)
poly = PolynomialFeatures(degree=2, include_bias=False)
X_poly = poly.fit_transform(df[['Feature1']])  # Feature1 has heavy impact

from sklearn.preprocessing import StandardScaler

scaler = StandardScaler()
df[['Feature1']] = scaler.fit_transform(df[['Feature1']])


from statsmodels.stats.outliers_influence import variance_inflation_factor

X = df[['Feature1', 'Feature2', 'Feature3']]
vif_data = pd.DataFrame()
vif_data["Feature"] = X.columns
vif_data["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]

print(vif_data)


from sklearn.linear_model import Ridge, Lasso

ridge = Ridge(alpha=1.0)  # Adjust alpha to control penalty
lasso = Lasso(alpha=0.1)

ridge.fit(X_train, y_train)
lasso.fit(X_train, y_train)

