from sklearn.model_selection import GridSearchCV
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score
import numpy as np

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

# Set random seed for reproducibility
np.random.seed(42)

# Generate a synthetic dataset with a quadratic relationship
# Create a range of ages between 20 and 80
ages = np.random.randint(20, 80, 500)

# Create a quadratic relationship for the Blood Pressure reduction: 
# Assuming the effect is stronger in middle age, and weaker in both younger and older ages.
# Effect increases up to 40, then decreases after 40
bp_reduction = 30 - 0.1*(ages - 40)**2 + np.random.normal(0, 5, 500)  # Adding some noise

# Ensure BP reduction is non-negative
bp_reduction = np.clip(bp_reduction, 0, None)

# Generate a gender column randomly
genders = np.random.choice(['Male', 'Female'], 500)

# Create a drug column, assuming Drug A is slightly more effective for younger people
drugs = np.random.choice(['Drug A', 'Drug B'], 500)

# Create the dataset
df = pd.DataFrame({
    'Age': ages,
    'Gender': genders,
    'Drug': drugs,
    'Blood Pressure Before': np.random.randint(140, 180, 500),
    'Blood Pressure After': np.random.randint(120, 160, 500),
    'Reduction in BP (mmHg)': bp_reduction
})

# Add a non-linear (quadratic) feature Age^2
df['Age^2'] = df['Age']**2

# Plotting the relationship between Age and BP Reduction
plt.scatter(df['Age'], df['Reduction in BP (mmHg)'], color='blue', alpha=0.5, label="Age vs BP Reduction")
plt.xlabel("Age")
plt.ylabel("Blood Pressure Reduction (mmHg)")
plt.title("Age vs Blood Pressure Reduction (Quadratic Effect)")
plt.show()

# Display the first few rows of the dataset
print(df.head())

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error
import seaborn as sns

# Prepare the features and target variable
X = df[['Age', 'Age^2']]  # Including Age and Age^2
y = df['Reduction in BP (mmHg)']

# Split the data into training and test sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Initialize and train models
# 1. Linear Regression Model (to check if Age and Age^2 can capture non-linearity)
linear_model = LinearRegression()
linear_model.fit(X_train, y_train)

# 2. Random Forest Regressor (a non-linear model)
rf_model = RandomForestRegressor(n_estimators=100, random_state=42)
rf_model.fit(X_train, y_train)

# Predictions and evaluation
y_pred_linear = linear_model.predict(X_test)
y_pred_rf = rf_model.predict(X_test)

# Calculate Mean Squared Error (MSE) for both models
mse_linear = mean_squared_error(y_test, y_pred_linear)
mse_rf = mean_squared_error(y_test, y_pred_rf)

# Display the results: exact MSE values
print("Linear Model MSE: ", mse_linear)
print("RandomForest Model MSE: ", mse_rf)

# Re-run feature importance for Random Forest
feature_importances = rf_model.feature_importances_

# Visualizing feature importance
plt.barh(X.columns, feature_importances)
plt.xlabel("Feature Importance")
plt.title("Feature Importance for Random Forest Model")


plt.show()

# Evaluate the model performance using R-squared
from sklearn.metrics import r2_score

# R-squared for Linear Model
r2_linear = r2_score(y_test, y_pred_linear)

# R-squared for Random Forest Model
r2_rf = r2_score(y_test, y_pred_rf)

# Plot residuals for Random Forest model
plt.scatter(y_test, y_pred_rf - y_test, color='red', alpha=0.5)
plt.axhline(y=0, color='black', linestyle='--')
plt.xlabel("True Blood Pressure Reduction")
plt.ylabel("Residuals")
plt.title("Residual Plot: Random Forest Model")
plt.show()

# Display R-squared values for both models
r2_linear, r2_rf

# Visualizing predictions
sns.scatterplot(x=y_test, y=y_pred_linear, color='blue', label='Linear Model Predictions')
sns.scatterplot(x=y_test, y=y_pred_rf, color='red', label='Random Forest Predictions')
plt.xlabel("True Blood Pressure Reduction")
plt.ylabel("Predicted Blood Pressure Reduction")
plt.title("Predictions: Linear Model vs Random Forest")
plt.legend()
plt.show()

# Define the parameter grid for hyperparameter tuning
param_grid = {
    'n_estimators': [50, 100, 200],
    'max_depth': [None, 5, 10, 20],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', None]
}

# Initialize a RandomForestRegressor
rf = RandomForestRegressor(random_state=42)

# Setup the GridSearchCV with 5-fold cross-validation
grid_search = GridSearchCV(estimator=rf, 
                           param_grid=param_grid,
                           cv=5, 
                           n_jobs=-1, 
                           scoring='neg_mean_squared_error', 
                           verbose=1)

# Fit GridSearchCV on the training data
grid_search.fit(X_train, y_train)

# Retrieve the best parameters and best score
best_params = grid_search.best_params_
best_rmse = np.sqrt(-grid_search.best_score_)  # Converting negative MSE to RMSE for easier interpretation

print("Best Hyperparameters:", best_params)
print("Best Cross-Validated RMSE:", best_rmse)

# Use the best estimator to make predictions on the test set
best_rf_model = grid_search.best_estimator_
y_pred_best = best_rf_model.predict(X_test)

# Evaluate the tuned model on the test set
mse_best = mean_squared_error(y_test, y_pred_best)
r2_best = r2_score(y_test, y_pred_best)

print("Test Set MSE of the Best Model:", mse_best)
print("Test Set R-squared of the Best Model:", r2_best)
