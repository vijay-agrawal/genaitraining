# If needed, install dependencies:
# !pip install transformers torch

import torch
from transformers import GPT2Tokenizer, GPT2LMHeadModel

# 1. Load the tokenizer and model
tokenizer = GPT2Tokenizer.from_pretrained("gpt2")
model = GPT2LMHeadModel.from_pretrained("gpt2")

# 2. Prepare input prompt
prompt_text = "Hello, my name is"

# Step 1: tokenize the input
input_ids = tokenizer.encode(prompt_text, return_tensors="pt")

# 3. Run the model
with torch.no_grad():
    output = model(input_ids)

# 'logits' are the raw prediction scores before SoftMax
logits = output.logits

# 4. The last token prediction is at index [-1] of the sequence
last_token_logits = logits[0, -1, :]

# 5. Pick the most likely next token id
next_token_id = torch.argmax(last_token_logits)

# 6. Decode that token to get the next word (or subword)
next_token_str = tokenizer.decode(next_token_id)

print("Given prompt:", prompt_text)
print("Predicted next token:", repr(next_token_str))
print("Extended text:", prompt_text + next_token_str)

# 5. Get the top 5 predictions
top_k = 5
top_k_scores, top_k_ids = torch.topk(last_token_logits, k=top_k)

print("Prompt:", prompt_text)
print(f"Top {top_k} predictions for the next token:")

for i, (score, token_id) in enumerate(zip(top_k_scores, top_k_ids)):
    token_str = tokenizer.decode([token_id])
    print(f"  {i+1}. Token: {repr(token_str)}\tLogit: {score.item():.2f}")

########################################
# EXAMPLE 2: Convert logits to probabilities
#           and show top-k tokens by probability
########################################
import torch.nn.functional as F

probabilities = F.softmax(last_token_logits, dim=-1)
top_k_probs, top_k_ids = torch.topk(probabilities, k=top_k)

print("\n=== Top 5 tokens by probability ===")
for i, (prob, token_id) in enumerate(zip(top_k_probs, top_k_ids)):
    token_str = tokenizer.decode([token_id])
    print(f"{i+1}. Token: {repr(token_str)} | Probability: {prob.item():.4f}")

########################################
# EXAMPLE 3: Filter out single-letter tokens
#            and then pick the top 5 valid tokens
########################################
# Sort all logits from highest to lowest.
sorted_scores, sorted_ids = torch.sort(last_token_logits, descending=True)

filtered = []
for score, token_id in zip(sorted_scores, sorted_ids):
    token_str = tokenizer.decode([token_id])
    # Strip leading/trailing whitespace to check the "core" subword.
    # Adjust the filtering logic to suit your needs.
    if len(token_str.strip()) > 1:
        # We only add tokens that have more than 1 character
        # (i.e., ignoring single-letter tokens).
        filtered.append((score, token_id))
    if len(filtered) == 5:
        break

print("\n=== Top 5 tokens ignoring single-letter subwords ===")
for i, (score, token_id) in enumerate(filtered):
    token_str = tokenizer.decode([token_id])
    print(f"{i+1}. Token: {repr(token_str)} | Logit: {score.item():.2f}")
    