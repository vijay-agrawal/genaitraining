# File: 00python/data_loader.py
# Simple script to load and analyze loan approval data

import pandas as pd
import os

# Define the path to the data file
data_path = "00python/data/loanapproval_hist_data.csv"

try:
    # Check if file exists
    if not os.path.exists(data_path):
        print(f"Error: File not found at {data_path}")
        exit
    
    # Load the CSV file into a pandas DataFrame
    print("Loading data...")
    df = pd.read_csv(data_path)
    
    # Print top 5 rows
    print("\n=== TOP 5 ROWS ===")
    print(df.head())
    
    # Print number of rows and columns
    print(f"\n=== DATA SHAPE ===")
    print(f"Number of rows: {df.shape[0]}")
    print(f"Number of columns: {df.shape[1]}")
    
    # Print column types
    print(f"\n=== COLUMN TYPES ===")
    print(df.dtypes)
except FileNotFoundError:
    print(f"Error: Could not find the file at {data_path}")
except Exception as e:
    print(f"Error loading data: {e}")

