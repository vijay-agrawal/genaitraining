import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Generate synthetic healthcare data (Age, Cholesterol) for heart disease classification
np.random.seed(42)
n_samples = 100

# Generate cholesterol values (100-400)
cholesterol = np.random.randint(100, 400, n_samples)

# Generate labels: 1 if cholesterol > 250, else 0 (Heart Disease Presence)
heart_disease = (cholesterol > 250).astype(int)

# Normalize cholesterol values
cholesterol_norm = (cholesterol - np.mean(cholesterol)) / np.std(cholesterol)

# Initialize weight and bias
w = np.random.randn()
b = np.random.randn()

# Define Sigmoid function
def sigmoid(z):
    return 1 / (1 + np.exp(-z))

# Define Cross-Entropy Loss
def cross_entropy_loss(y, p):
    return -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))

# Training parameters
learning_rate = 0.1
epochs = 500
losses = []

# Gradient Descent Training Loop
for epoch in range(epochs):
    # Compute predictions
    z = w * cholesterol_norm + b
    predictions = sigmoid(z)

    # Compute loss
    loss = cross_entropy_loss(heart_disease, predictions)
    losses.append(loss)

    # Compute gradients
    dw = np.mean((predictions - heart_disease) * cholesterol_norm)
    db = np.mean(predictions - heart_disease)

    # Update parameters
    w -= learning_rate * dw
    b -= learning_rate * db

# Plotting results
plt.figure(figsize=(12, 5))

# Plot 1: Cross-Entropy Loss Over Time
plt.subplot(1, 2, 1)
plt.plot(range(epochs), losses, color='red')
plt.xlabel("Epoch")
plt.ylabel("Cross-Entropy Loss")
plt.title("Loss Reduction Over Training")
plt.grid(True)

# Plot 2: Decision Boundary
plt.subplot(1, 2, 2)
plt.scatter(cholesterol, heart_disease, c=heart_disease, cmap="bwr", alpha=0.6, label="Actual")
plt.plot(cholesterol, sigmoid(w * cholesterol_norm + b), color='black', label="Predicted Probability")
plt.xlabel("Cholesterol Level")
plt.ylabel("Probability of Heart Disease")
plt.title("Logistic Regression Decision Boundary")
plt.legend()
plt.grid(True)

plt.tight_layout()
plt.show()
