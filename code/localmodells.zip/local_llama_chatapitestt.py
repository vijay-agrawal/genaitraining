import openai

openai.api_base = "http://127.0.0.1:1234/v1"

# You can disable SSL verification for local testing if needed
openai.verify_ssl_certs = False
openai.api_key = "xyz"

response = openai.chat.completions.create(
    model="llama-3.2-3b-instruct",
    messages=[
        {"role": "user", 
         "content": "What is the capital of France?"
         }
         ],
    max_tokens=150
)

# If getting connection error, use older version of openai
# 0.28.1 as LM Studio API Server is based on a older version implementation
# 
print(response)
