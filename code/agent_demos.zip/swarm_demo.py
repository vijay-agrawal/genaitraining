import openai
from openai_swarm import Swarm, Worker, Chat

###############################################################################
# 1. Configure Azure OpenAI
###############################################################################
# Set your Azure OpenAI configuration. 
# Make sure these match your Azure Portal settings.
openai.api_type = "azure"
openai.api_base = "https://YOUR_AZURE_OPENAI_ENDPOINT.openai.azure.com"
openai.api_version = "2023-03-15-preview"  # or the version your endpoint supports
openai.api_key = "YOUR_AZURE_OPENAI_API_KEY"


###############################################################################
# 2. Create Agent Classes
###############################################################################
class DiseaseTreatmentResearchAgent(Worker):
    """
    Fetches or constructs news items about disease treatments / research.
    """
    def __init__(self, disease: str):
        super().__init__()
        self.disease = disease

    def do_work(self):
        # In reality, you'd call an external API here.
        # For demo purposes, we return a list of dummy strings.
        return [
            f"New clinical trial shows promise for {self.disease} treatment.",
            f"Breakthrough study on gene therapy for {self.disease} was published."
        ]


class MedicationAgent(Worker):
    """
    Fetches or constructs news items about medications / drugs.
    """
    def __init__(self, disease: str):
        super().__init__()
        self.disease = disease

    def do_work(self):
        # In reality, you'd call an external API here.
        # For demo purposes, we return a list of dummy strings.
        return [
            f"FDA approves new drug for {self.disease}.",
            f"Guidelines updated for prescribing {self.disease} medication."
        ]


class SummarizationAgent(Worker):
    """
    Uses the Azure OpenAI LLM to summarize combined news for a disease.
    """
    def __init__(self, disease: str, research_items, medication_items):
        super().__init__()
        self.disease = disease
        self.research_items = research_items
        self.medication_items = medication_items

    def do_work(self):
        # Create a Chat instance from openai-swarm
        chat = Chat(
            system="You are a helpful AI assistant specializing in summarizing healthcare news.",
            openai_config={
                "api_type": "azure",
                "api_base": openai.api_base,       # Use the same config as above
                "api_version": openai.api_version,
                "api_key": openai.api_key
            },
            deployment_id="YOUR_MODEL_DEPLOYMENT_NAME"  # e.g., "gpt-35-turbo", etc.
        )

        # Prompt: Summarize the items
        user_prompt = f"""
Summarize these latest news items about {self.disease}:

Treatment / Research:
{self.research_items}

Medications / Drugs:
{self.medication_items}

Format your response as a short paragraph.
"""

        # Use the Chat instance to call Azure OpenAI
        response = chat.ask(user_prompt)
        return response


###############################################################################
# 3. Orchestrate Agents with a Swarm
###############################################################################
def get_healthcare_news_for_disease(disease: str):
    # Create swarm and add data-gathering agents
    swarm = Swarm()
    swarm.add("treatment_research", DiseaseTreatmentResearchAgent(disease))
    swarm.add("medication_news", MedicationAgent(disease))

    # Run them in parallel
    results = swarm.run()  # dict with keys "treatment_research" and "medication_news"

    # Now we feed those results to our summarization agent
    summarizer = SummarizationAgent(
        disease,
        results["treatment_research"],
        results["medication_news"]
    )

    # We could add the summarizer to the swarm, but we can just run it directly:
    summary = summarizer.do_work()

    # Return both raw and summarized results, if desired
    return {
        "raw_news": results,
        "summary": summary
    }


###############################################################################
# 4. Example Usage
###############################################################################
if __name__ == "__main__":
    user_disease = "diabetes"  # Normally you'd get this from user input
    news_output = get_healthcare_news_for_disease(user_disease)

    print("==== RAW NEWS ====")
    for category, articles in news_output["raw_news"].items():
        print(f"\n--- {category.upper()} ---")
        for article in articles:
            print("*", article)

    print("\n==== LLM SUMMARY ====")
    print(news_output["summary"])
