# Make sure in .env file in your project root, following lines are present with valid values:
# AWS_ACCESS_KEY_ID=< your access key id>
# AWS_SECRET_ACCESS_KEY=<your secret access key>
# AWS_REGION=<your default region>

import os
from dotenv import load_dotenv
import boto3

# Load environment variables from .env file
load_dotenv()

# Access AWS credentials from environment variables
aws_access_key_id = os.environ.get('AWS_ACCESS_KEY_ID')
aws_secret_access_key = os.environ.get('AWS_SECRET_ACCESS_KEY')
aws_region = os.environ.get('AWS_REGION')

# Verify that credentials are available
if not all([aws_access_key_id, aws_secret_access_key, aws_region]):
    print("Error: AWS credentials or region not found in environment variables")
    exit(1)

# Create a session using the credentials
session = boto3.Session(
    aws_access_key_id=aws_access_key_id,
    aws_secret_access_key=aws_secret_access_key,
    region_name=aws_region
)

# Now you can create any service client using this session
s3 = session.client('s3')
print("Successfully connected to AWS S3")

# Example: List all S3 buckets
try:
    response = s3.list_buckets()
    print("S3 Buckets:")
    for bucket in response['Buckets']:
        print(f"  - {bucket['Name']}")
except Exception as e:
    print(f"Error listing buckets: {e}")
