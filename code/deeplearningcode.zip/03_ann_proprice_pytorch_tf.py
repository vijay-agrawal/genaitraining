import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split

# Synthesizing a dataset of 100 rows for property prices in Pune
np.random.seed(42)

locations = ['Koregaon Park', 'Hinjewadi', 'Baner', 'Kothrud', 'Wakad', 'Hadapsar', 'Viman Nagar', 'Aundh']
num_samples = 100

data = {
    'sq_ft': np.random.randint(500, 3000, num_samples),
    'bedrooms': np.random.randint(1, 5, num_samples),
    'bathrooms': np.random.randint(1, 4, num_samples),
    'location': np.random.choice(locations, num_samples),
    'price': np.random.randint(30, 300, num_samples) * 10000  # Property prices in INR (scaled)
}

df = pd.DataFrame(data)

print(df.head())

# Encoding categorical location feature
encoder = LabelEncoder()
df['location'] = encoder.fit_transform(df['location'])

# Splitting into features and target
X = df.drop(columns=['price'])
y = df['price']

# Standardizing features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

# Train-test split
X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import tensorflow as tf
from tensorflow import keras
from tensorflow.keras import layers

# Convert Mumbai data to PyTorch tensors
X_train_tensor = torch.tensor(X_train, dtype=torch.float32)
y_train_tensor = torch.tensor(y_train.values, dtype=torch.float32).view(-1, 1)
X_test_tensor = torch.tensor(X_test, dtype=torch.float32)
y_test_tensor = torch.tensor(y_test.values, dtype=torch.float32).view(-1, 1)

# Define the ANN model
class PropertyPriceANN(nn.Module):
    def __init__(self):
        super(PropertyPriceANN, self).__init__()
        self.fc1 = nn.Linear(X_train.shape[1], 64)
        self.fc2 = nn.Linear(64, 32)
        self.fc3 = nn.Linear(32, 1)
        self.relu = nn.ReLU()
    
    def forward(self, x):
        x = self.relu(self.fc1(x))
        x = self.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Instantiate the model
model = PropertyPriceANN()

# Define loss function and optimizer
criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# Training loop
epochs = 500
for epoch in range(epochs):
    model.train()
    optimizer.zero_grad()
    predictions = model(X_train_tensor)
    loss = criterion(predictions, y_train_tensor)
    loss.backward()
    optimizer.step()
    
    if (epoch+1) % 100 == 0:
        print(f'Epoch {epoch+1}/{epochs}, Loss: {loss.item()}')

# Evaluating the model
model.eval()
y_pred = model(X_test_tensor).detach().numpy()
print("Sample Predictions:", y_pred[:5])

# Define the ANN model using TensorFlow
model_tf = keras.Sequential([
    layers.Dense(64, activation='relu', input_shape=(X_train.shape[1],)),
    layers.Dense(32, activation='relu'),
    layers.Dense(1)  # Output layer
])

# Compile the model
model_tf.compile(optimizer='adam', loss='mse')

# Train the model
model_tf.fit(X_train, y_train, epochs=500, verbose=0, batch_size=10)

# Evaluate and make predictions
y_pred_tf = model_tf.predict(X_test)
print("TensorFlow Sample Predictions:", y_pred_tf[:5])
