# Generate synthetic classification data
import numpy as np  # For numerical operations
import matplotlib.pyplot as plt  # For plotting results

np.random.seed(42)
X_class = np.random.rand(100, 2) * 10  # Two input features
y_class = (X_class[:, 0] + X_class[:, 1] > 10).astype(int).reshape(-1, 1)  # Label: 1 if sum > 10, else 0

# Initialize network parameters
input_size = 2
hidden_size = 5
output_size = 1
learning_rate = 0.01

# Weights and biases
W1 = np.random.randn(input_size, hidden_size)  # Input to Hidden layer
b1 = np.zeros((1, hidden_size))  # Bias for hidden layer
W2 = np.random.randn(hidden_size, output_size)  # Hidden to Output layer
b2 = np.zeros((1, output_size))  # Bias for output layer

# relu activation function for hidden layer
def relu(Z):
    return np.maximum(0, Z)  # ReLU: max(0, Z)

def relu_derivative(Z):
    return (Z > 0).astype(float)  # Derivative of ReLU (1 if Z > 0, else 0)


# Sigmoid activation function for output layer
def sigmoid(Z):
    return 1 / (1 + np.exp(-Z))

def sigmoid_derivative(Z):
    return sigmoid(Z) * (1 - sigmoid(Z))

# Forward pass function
def forward_classification(X):
    Z1 = X.dot(W1) + b1  # Linear transformation (Input to Hidden)
    A1 = relu(Z1)  # Activation function (ReLU)
    Z2 = A1.dot(W2) + b2  # Linear transformation (Hidden to Output)
    A2 = sigmoid(Z2)  # Sigmoid activation for classification
    return Z1, A1, Z2, A2

# Binary Cross-Entropy loss function
def binary_cross_entropy(y_true, y_pred):
    epsilon = 1e-9  # Avoid log(0)
    return -np.mean(y_true * np.log(y_pred + epsilon) + (1 - y_true) * np.log(1 - y_pred + epsilon))

# Training loop with manual backpropagation
losses_class = []
epochs = 1000

for epoch in range(epochs):
    # Forward pass
    Z1, A1, Z2, A2 = forward_classification(X_class)
    y_pred_class = A2  # Output probability

    # Compute loss
    loss = binary_cross_entropy(y_class, y_pred_class)
    losses_class.append(loss)

    # Backpropagation
    dZ2 = (y_pred_class - y_class) / y_class.shape[0]  # Derivative of BCE loss
    dW2 = A1.T.dot(dZ2)  # Gradient for W2
    db2 = np.sum(dZ2, axis=0, keepdims=True)  # Gradient for b2

    dA1 = dZ2.dot(W2.T)  # Gradient through W2
    dZ1 = dA1 * relu_derivative(Z1)  # Gradient through ReLU
    dW1 = X_class.T.dot(dZ1)  # Gradient for W1
    db1 = np.sum(dZ1, axis=0, keepdims=True)  # Gradient for b1

    # Update weights
    W1 -= learning_rate * dW1
    b1 -= learning_rate * db1
    W2 -= learning_rate * dW2
    b2 -= learning_rate * db2

# Plot loss curve for classification
plt.plot(losses_class)
plt.xlabel("Epochs")
plt.ylabel("Binary Cross-Entropy Loss")
plt.title("Loss Curve for Classification")
plt.show()

# Predict and visualize decision boundary
y_pred_class_binary = (y_pred_class > 0.5).astype(int)

plt.scatter(X_class[:, 0], X_class[:, 1], c=y_class.flatten(), label="Actual", cmap="coolwarm", edgecolors="k")
plt.scatter(X_class[:, 0], X_class[:, 1], c=y_pred_class_binary.flatten(), marker="x", label="Predicted", cmap="coolwarm")
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("Binary Classification using Neural Network")
plt.legend()
plt.show()
