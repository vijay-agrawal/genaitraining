import numpy as np
import pandas as pd
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import SimpleRNN, LSTM, Dense
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.utils import to_categorical

# Set random seed for reproducibility
np.random.seed(42)
tf.random.set_seed(42)

# Generate synthetic patient data
num_samples = 2000  # Number of patients
sequence_length = 10  # 10 years of historical data
num_features = 5  # Blood sugar, blood pressure, medication adherence, lab results, lifestyle habits

# Generate random health records (normalized values between 0 and 1)
X_data = np.random.rand(num_samples, sequence_length, num_features)

# Generate synthetic labels: 0 (No kidney failure), 1 (Kidney failure)
y_data = np.random.choice([0, 1], size=(num_samples,))

# Encode labels
label_encoder = LabelEncoder()
y_data_encoded = label_encoder.fit_transform(y_data)
y_data_onehot = to_categorical(y_data_encoded)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_data, y_data_onehot, test_size=0.2, random_state=42)

# Define RNN model
rnn_model = Sequential([
    SimpleRNN(32, activation='relu', input_shape=(sequence_length, num_features)),
    Dense(16, activation='relu'),
    Dense(2, activation='softmax')  # Binary classification (Kidney failure: Yes/No)
])

rnn_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train RNN model
rnn_model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test), verbose=1)

# Evaluate RNN model
rnn_loss, rnn_accuracy = rnn_model.evaluate(X_test, y_test, verbose=0)

# Define LSTM model
lstm_model = Sequential([
    LSTM(32, activation='relu', input_shape=(sequence_length, num_features)),
    Dense(16, activation='relu'),
    Dense(2, activation='softmax')  # Binary classification
])

lstm_model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# Train LSTM model
lstm_model.fit(X_train, y_train, epochs=10, batch_size=32, validation_data=(X_test, y_test), verbose=1)

# Evaluate LSTM model
lstm_loss, lstm_accuracy = lstm_model.evaluate(X_test, y_test, verbose=0)

# Compare results
results_df = pd.DataFrame({
    "Model": ["RNN", "LSTM"],
    "Loss": [rnn_loss, lstm_loss],
    "Accuracy": [rnn_accuracy, lstm_accuracy]
})

print("\nComparison of RNN vs LSTM Performance:")
print(results_df)
