from flask import Flask, request, jsonify
import torch
from transformers import GPT2LMHeadModel, GPT2TokenizerFast
import time

app = Flask(__name__)

# Global variables for model and tokenizer
model = None
tokenizer = None
device = None

def load_model():
    """Load the model and tokenizer"""
    global model, tokenizer, device
    
    try:
        print("Loading model and tokenizer...")
        model_name = "./fine_tuned_model"  # adjust if your model is saved elsewhere
        
        # Load tokenizer and model
        tokenizer = GPT2TokenizerFast.from_pretrained(model_name)
        model = GPT2LMHeadModel.from_pretrained(model_name)
        
        # Set pad token to EOS token if not already set
        if tokenizer.pad_token is None:
            tokenizer.pad_token = tokenizer.eos_token
        model.config.pad_token_id = tokenizer.eos_token_id

        # Move model to GPU if available
        device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        model.to(device)
        model.eval()
        
        print(f"Model loaded successfully on {device}")
        return True
        
    except Exception as e:
        print(f"Error loading model: {e}")
        return False

@app.route('/v1/completions', methods=['POST'])
def generate():
    global model, tokenizer, device
    
    # Check if model is loaded
    if model is None or tokenizer is None:
        if not load_model():
            return jsonify({"error": "Failed to load model"}), 500
    
    try:
        # Get request data
        data = request.json
        print("Request data:", data)
        
        prompt_text = data.get("prompt", "")
        max_tokens = data.get("max_tokens", 100)
        temperature = data.get("temperature", 0.7)
        top_p = data.get("top_p", 0.9)
        model_name = data.get("model", "llama-3.2-3b-instruct")  # From client request
        
        print(f"Prompt: {prompt_text}")
        
        if not prompt_text:
            return jsonify({
                "error": {
                    "message": "No prompt provided",
                    "type": "invalid_request_error"
                }
            }), 400

        # Create the input text following your format
        input_text = f"Prompt: {prompt_text}\nResponse:"
        
        # Tokenize the input
        inputs = tokenizer(
            input_text, 
            return_tensors="pt", 
            truncation=True, 
            max_length=512
        ).to(device)
        
        # Generate response
        with torch.no_grad():
            output_sequences = model.generate(
                input_ids=inputs["input_ids"],
                attention_mask=inputs["attention_mask"],
                max_new_tokens=max_tokens,  # Use max_new_tokens instead of max_length
                temperature=temperature,
                top_p=top_p,
                do_sample=True,
                num_return_sequences=1,
                pad_token_id=tokenizer.eos_token_id,
                eos_token_id=tokenizer.eos_token_id
            )
        
        # Decode the generated text
        generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
        
        # Extract only the response part (after "Response:")
        if "Response:" in generated_text:
            response_text = generated_text.split("Response:", 1)[1].strip()
        else:
            response_text = generated_text.replace(input_text, "").strip()
        
        # Calculate token counts (approximate)
        prompt_tokens = len(tokenizer.encode(prompt_text))
        completion_tokens = len(tokenizer.encode(response_text))
        total_tokens = prompt_tokens + completion_tokens
        
        # Return in OpenAI API format
        response = {
            "id": f"cmpl-{int(time.time() * 1000000)}",
            "object": "text_completion",
            "created": int(time.time()),
            "model": model_name,
            "choices": [
                {
                    "text": response_text,
                    "index": 0,
                    "logprobs": None,
                    "finish_reason": "stop"
                }
            ],
            "usage": {
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "total_tokens": total_tokens
            }
        }
        
        print(f"Generated response: {response_text[:100]}...")
        return jsonify(response)
        
    except Exception as e:
        print(f"Error during generation: {e}")
        return jsonify({
            "error": {
                "message": f"Internal server error: {str(e)}",
                "type": "server_error"
            }
        }), 500

@app.route('/v1/models', methods=['GET'])
def list_models():
    """Optional: Endpoint to list available models"""
    return jsonify({
        "object": "list",
        "data": [
            {
                "id": "llama-3.2-3b-instruct",
                "object": "model",
                "created": int(time.time()),
                "owned_by": "local"
            }
        ]
    })

@app.route('/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    status = "healthy" if model is not None else "model_not_loaded"
    return jsonify({"status": status, "device": str(device) if device else "none"})

if __name__ == '__main__':
    print("Starting Flask server...")
    print("Loading model on startup...")
    if load_model():
        print("Model loaded successfully, starting server...")
    else:
        print("Warning: Model failed to load, will retry on first request")
    
    app.run(host='0.0.0.0', port=5001, debug=True)