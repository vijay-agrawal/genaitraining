# Import necessary libraries for model training and data manipulation
import os
import torch
import pandas as pd
from datasets import Dataset
from transformers import GPT2LMHeadModel, GPT2TokenizerFast, Trainer, TrainingArguments, DataCollatorForLanguageModeling


# -------------------------------
# 1. Load and Prepare the Dataset
# -------------------------------
# Assume your CSV has columns: "instruction" and "response"
df = pd.read_csv("medical_qa.csv")

# Combine the prompt and response into a single text field.
def combine_prompt_response(row):
    # You can customize this format as needed.
    return f"Prompt: {row['instruction']}\nResponse: {row['response']}\n"

df["text"] = df.apply(combine_prompt_response, axis=1)

# Convert the DataFrame to a Hugging Face Dataset.
dataset = Dataset.from_pandas(df[["text"]])

# -------------------------------
# 2. Tokenize the Dataset
# -------------------------------
model_name = "gpt2"  # using GPT-2 as an example model

tokenizer = GPT2TokenizerFast.from_pretrained(model_name)

# GPT-2 does not have a padding token by default; add one.
tokenizer.pad_token = tokenizer.eos_token

# Fixed tokenization function: ensure attention_mask is included
def tokenize_function(examples):
    # Tokenize and return both input_ids and attention_mask
    result = tokenizer(
        examples["text"], 
        truncation=True, 
        max_length=512, 
        padding="max_length",
        return_attention_mask=True  # Explicitly request attention mask
    )
    # For language modeling, labels should be the same as input_ids
    result["labels"] = result["input_ids"].copy()
    return result

tokenized_dataset = dataset.map(tokenize_function, batched=True, remove_columns=["text"])

# Split the dataset into training and evaluation sets.
split_dataset = tokenized_dataset.train_test_split(test_size=0.1)
train_dataset = split_dataset["train"]
eval_dataset = split_dataset["test"]

# -------------------------------
# 3. Establish baseline
# -------------------------------
print("Response BEFORE fine-tuning:")
prompt_text = "What is a quick Ayurvedic fix for a mild stomach ache?"
input_text = f"Prompt: {prompt_text}\nResponse:"

# Define the device
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

# Load the pre-trained GPT-2 model
model = GPT2LMHeadModel.from_pretrained(model_name).to(device)

# Tokenize input with attention mask
inputs = tokenizer(input_text, return_tensors="pt", return_attention_mask=True)
inputs = {k: v.to(device) for k, v in inputs.items()}  # Move all tensors to device

# Generate a response using the pre-trained model.
model.eval()
with torch.no_grad():
    output_sequences = model.generate(
        input_ids=inputs["input_ids"],
        attention_mask=inputs["attention_mask"],  # Include attention mask
        max_length=150,      # adjust maximum generation length as needed
        temperature=0.7,     # control randomness
        top_p=0.9,           # nucleus sampling
        do_sample=True,
        num_return_sequences=1,
        pad_token_id=tokenizer.eos_token_id,  # Specify pad token
    )

generated_text = tokenizer.decode(output_sequences[0], skip_special_tokens=True)
print("Generated Response (Before Fine-Tuning):")
print(generated_text)
print("-" * 80)

# -------------------------------
# 4. Fine-Tune the Model
# -------------------------------
# Load pre-trained GPT-2 model for fine-tuning.
model = GPT2LMHeadModel.from_pretrained(model_name)
# Set the model's pad token id to match the tokenizer.
model.config.pad_token_id = tokenizer.eos_token_id

# Create a data collator for language modeling with proper attention mask handling
data_collator = DataCollatorForLanguageModeling(
    tokenizer=tokenizer, 
    mlm=False,  # We're doing causal language modeling, not masked language modeling
    return_tensors="pt"
)

# Set training arguments.
training_args = TrainingArguments(
    output_dir="./gpt2-ayurveda-finetuned",
    overwrite_output_dir=True,
    num_train_epochs=3,                     # adjust as needed
    per_device_train_batch_size=2,          # adjust based on your GPU/CPU
    per_device_eval_batch_size=2,
    evaluation_strategy="epoch",
    learning_rate=5e-5,
    weight_decay=0.01,
    logging_steps=10,
    save_steps=500,
    save_total_limit=2,                     # Limit number of saved checkpoints
    load_best_model_at_end=True,
    metric_for_best_model="eval_loss",
    greater_is_better=False,
    fp16=torch.cuda.is_available(),         # enables FP16 training if supported
    dataloader_pin_memory=False,            # Can help with memory issues
)

# Initialize the Trainer.
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    data_collator=data_collator,
)

# Fine-tune the model.
print("Starting fine-tuning...")
trainer.train()

# Save the fine-tuned model and tokenizer.
trainer.save_model("./fine_tuned_model")
tokenizer.save_pretrained("./fine_tuned_model")

print("Fine-tuning completed and model saved!")

# -------------------------------
# 5. Test the fine-tuned model
# -------------------------------
print("\nResponse AFTER fine-tuning:")

# Load the fine-tuned model
fine_tuned_model = GPT2LMHeadModel.from_pretrained("./fine_tuned_model").to(device)
fine_tuned_tokenizer = GPT2TokenizerFast.from_pretrained("./fine_tuned_model")

# Test with the same prompt
inputs = fine_tuned_tokenizer(input_text, return_tensors="pt", return_attention_mask=True)
inputs = {k: v.to(device) for k, v in inputs.items()}

fine_tuned_model.eval()
with torch.no_grad():
    output_sequences = fine_tuned_model.generate(
        input_ids=inputs["input_ids"],
        attention_mask=inputs["attention_mask"],
        max_length=150,
        temperature=0.7,
        top_p=0.9,
        do_sample=True,
        num_return_sequences=1,
        pad_token_id=fine_tuned_tokenizer.eos_token_id,
    )

generated_text_finetuned = fine_tuned_tokenizer.decode(output_sequences[0], skip_special_tokens=True)
print("Generated Response (After Fine-Tuning):")
print(generated_text_finetuned)