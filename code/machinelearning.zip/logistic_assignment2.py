# Import necessary libraries
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score

# Simulate a healthcare insurance fraud dataset
np.random.seed(42)
n_samples = 1000

# Generate random features
age = np.random.randint(18, 80, n_samples)
income = np.random.randint(20000, 150000, n_samples)
claim_amount = np.random.randint(1000, 50000, n_samples)
num_claims = np.random.randint(0, 5, n_samples)

# Generate fraud labels (0 = No Fraud, 1 = Small Fraud, 2 = Large Fraud)
fraud_labels = np.random.choice([0, 1, 2], size=n_samples, p=[0.7, 0.2, 0.1])  # Skewed dataset

# Create a DataFrame
df = pd.DataFrame({
    'Age': age,
    'Income': income,
    'ClaimAmount': claim_amount,
    'NumClaims': num_claims,
    'FraudType': fraud_labels
})

# Split data into train and test sets
X = df.drop(columns=['FraudType'])
y = df['FraudType']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

# Standardize numerical features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Train a multinomial logistic regression model
model = LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=500)
model.fit(X_train_scaled, y_train)

# Make predictions
y_pred = model.predict(X_test)

# Evaluation metrics
accuracy = accuracy_score(y_test, y_pred)
f1 = f1_score(y_test, y_pred, average='weighted')  # Weighted F1-score for imbalanced data
conf_matrix = confusion_matrix(y_test, y_pred)
class_report = classification_report(y_test, y_pred)

# Display results
print(f"Accuracy: {accuracy:.4f}")
print(f"Weighted F1-score: {f1:.4f}")
print("\nClassification Report:\n", class_report)

# Plot confusion matrix
plt.figure(figsize=(6,5))
sns.heatmap(conf_matrix, annot=True, fmt="d", cmap="Blues", xticklabels=["No Fraud", "Small Fraud", "Large Fraud"], yticklabels=["No Fraud", "Small Fraud", "Large Fraud"])
plt.xlabel("Predicted")
plt.ylabel("Actual")
plt.title("Confusion Matrix")
plt.show()
 