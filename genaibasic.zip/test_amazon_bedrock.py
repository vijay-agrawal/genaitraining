import boto3
import json
import os
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# Initialize the Bedrock client with credentials from .env
bedrock_runtime = boto3.client(
    service_name='bedrock-runtime',
    region_name=os.getenv('AWS_REGION'),
    aws_access_key_id=os.getenv('AWS_ACCESS_KEY_ID'),
    aws_secret_access_key=os.getenv('AWS_SECRET_ACCESS_KEY')
)

# Define your prompt for Claude
request_body = {
    "anthropic_version": "bedrock-2023-05-31",
    "max_tokens": 1000,
    "temperature" : 0.2,
    "messages": [
        {"role": "user", 
         "content": "Explain how environment variables work in Python."}
    ]
}

# Make the API call to Claude
response = bedrock_runtime.invoke_model(
    modelId = "meta.llama3-8b-instruct-v1",
    # Or "meta.llama3-70b-instruct-v1" or "anthropic.claude-3-sonnet-20240229-v1:0"
    body=json.dumps(request_body)
)

# Parse the response
response_body = json.loads(response['body'].read())
print(response_body['content'][0]['text'])