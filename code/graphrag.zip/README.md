# GraphRAG Demo

This folder contains code for building a Retrieval-Augmented Generation (RAG) system using graph-based indexing and retrieval.

## Files

- `indexer.py` — Indexes the Disease Treatment pdf by finding the nodes and relationships from the document. (Using generated code & regular expressions) and stores it into a graph structure in neo4j for efficient retrieval.  
  *Comments: This script reads input data, processes it into nodes and relationships, and stores them in a graph database (such as Neo4j). It may include logic for parsing text, extracting entities, and creating graph schema.*
Note: Update the neo4j connection information in the indexer.py before runnning it.

- `retriever.py` — Implements retrieval logic to query the graph and fetch relevant information for downstream tasks.  
  *Comments: This script connects to the graph database, formulates Cypher queries with the help of LLM, and retrieves relevant nodes or subgraphs based on user queries or prompts. It then uses LLM reasoning with the above data context to formulate a response to the user question*
Note: Update the neo4j connection information in the retriever.py before runnning it.

