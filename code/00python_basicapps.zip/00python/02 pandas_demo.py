import pandas as pd

# Create demographic data for top 10 cities in India
data = {
    'City': ['Mumbai', 'Delhi', 'Bangalore', 'Hyderabad', 'Ahmedabad', 
             'Chennai', 'Kolkata', 'Surat', 'Pune', 'Jaipur'],
    'Population': [12442373, 11007835, 8443675, 6809970, 5577940,
                   4681087, 4496694, 4467797, 3124458, 3073350],
    'State': ['Maharashtra', 'Delhi', 'Karnataka', 'Telangana', 'Gujarat',
              'Tamil Nadu', 'West Bengal', 'Gujarat', 'Maharashtra', 'Rajasthan'],
    'Area_km2': [603, 1484, 741, 650, 505, 426, 206, 327, 331, 467],
    'Literacy_Rate': [89.73, 86.21, 88.71, 83.25, 88.29, 90.33, 86.31, 85.53, 86.15, 75.51]
}

# Create DataFrame
df = pd.DataFrame(data)

print("Top 10 Cities in India - Demographics")
print("=" * 40)
print(df.to_string(index=False))

print("\n" + "=" * 40)
print("Top 3 Cities by Population (Decreasing Order):")
print("=" * 40)

# Sort by population and get top 3
top_3 = df.nlargest(3, 'Population')[['City', 'Population', 'State']]
for i, row in top_3.iterrows():
    print(f"{row.name + 1}. {row['City']}, {row['State']} - {row['Population']:,}")