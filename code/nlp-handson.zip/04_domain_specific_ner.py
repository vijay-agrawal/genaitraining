from transformers import pipeline

def extract_medical_entities(text):
    """
    Extract medical entities from clinical text using a pre-trained NER model.
    
    Args:
        text (str): The clinical note text
        
    Returns:
        dict: Dictionary of extracted entities by type
    """
    # Load the medical NER model
    ner = pipeline(
        "ner",
        model="samrawal/bert-base-uncased_clinical-ner",
        aggregation_strategy="simple"
    )
    
    # Get predictions
    results = ner(text)
    
    # Organize entities by type
    entities = {
        "PROBLEM": [],
        "TREATMENT": [],
        "DRUG": [],
        "TEST": []
    }
    
    # Extract entities from results
    for entity in results:
        entity_type = entity.get('entity_group')
        entity_text = entity.get('word').strip()
        
        if entity_type in entities:
            entities[entity_type].append(entity_text)
    
    return entities

def generate_structured_summary(entities):
    """
    Generate a structured summary from the extracted entities.
    
    Args:
        entities (dict): Dictionary of categorized entities
        
    Returns:
        str: A structured summary
    """
    structured_text = ""
    
    if entities["PROBLEM"]:
        structured_text += f"Problems: {', '.join(entities['PROBLEM'])}. "
    
    if entities["TREATMENT"]:
        structured_text += f"Treatments: {', '.join(entities['TREATMENT'])}. "
    
    if entities["DRUG"]:
        structured_text += f"Drugs: {', '.join(entities['DRUG'])}. "
    
    if entities["TEST"]:
        structured_text += f"Tests: {', '.join(entities['TEST'])}. "
    
    return structured_text

# Example usage
if __name__ == "__main__":
    note = "Patient is a 60-year-old with Type 2 Diabetes. Reports dizziness over the last 3 weeks. Prescribed Ibuprofen 200mg. Recommended diet modifications."
    
    # Extract entities
    entities = extract_medical_entities(note)
    
    # Print extracted entities
    print("Extracted Entities:")
    for entity_type, items in entities.items():
        if items:
            print(f"{entity_type}: {', '.join(items)}")
    
    # Generate structured summary
    summary = generate_structured_summary(entities)
    print("\nStructured Summary:")
    print(summary)