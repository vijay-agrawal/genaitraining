import os
from dotenv import load_dotenv

load_dotenv()
key = "AZURE_OPENAI_ENDPOINT"
value = os.getenv(key)

print(f"Value for key {key} is {value}")
