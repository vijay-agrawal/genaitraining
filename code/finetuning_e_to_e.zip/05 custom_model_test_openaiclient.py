from openai import OpenAI

# Initialize the client with your local server configuration
client = OpenAI(
    base_url="http://127.0.0.1:5001/v1",  # Updated port to match Flask server
    api_key="xyz"  # Your API key
)

# For local testing, you might need to handle SSL verification differently
# The new API doesn't have a direct verify_ssl_certs parameter
# If you need to disable SSL verification, you can do it at the HTTP client level
import httpx

# Optional: Create a custom HTTP client with disabled SSL verification
http_client = httpx.Client(verify=False)

client = OpenAI(
    base_url="http://127.0.0.1:5001/v1",
    api_key="xyz",
    http_client=http_client
)

# Use the legacy completions endpoint that matches your Flask server
response = client.completions.create(
    model="llama-3.2-3b-instruct",
    prompt="What is ayurvedic remedy for cough?",
    max_tokens=150
)

# Debug: Print the full response to see what we're getting
print("Full response object:")
print(response)
print(f"Response type: {type(response)}")
print()

# Check if response has the expected structure
if hasattr(response, 'choices') and response.choices:
    print("Response text:")
    print(response.choices[0].text)
    
    # Print additional response information if available
    if hasattr(response, 'usage'):
        print(f"Usage: {response.usage}")
    if hasattr(response, 'id'):
        print(f"ID: {response.id}")
    if hasattr(response, 'model'):
        print(f"Model: {response.model}")
else:
    print("ERROR: Response doesn't have the expected 'choices' structure")
    print("Available attributes:", [attr for attr in dir(response) if not attr.startswith('_')])
    
    # Try to access response as a dictionary if it's not the expected object
    if isinstance(response, dict):
        print("Response as dictionary:")
        for key, value in response.items():
            print(f"  {key}: {value}")
    else:
        print("Response is not a dictionary either")
        print(f"Response content: {response}")