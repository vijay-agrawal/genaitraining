# File: 00python/weather_simple.py
# Simple script to get weather information for Mumbai using OpenWeatherMap API

import requests
import json

def main():
    # OpenWeatherMap API configuration
    API_KEY = "30d717876be7e2747bdf9d8cad1e8216"  # Replace with your actual API key
    BASE_URL = "http://api.openweathermap.org/data/2.5/weather"
    
    # City to get weather for
    city = "Mumbai"
    
    # Check if API key is set
    if API_KEY == "":
        print("Error: Please replace 'YOUR_API_KEY_HERE' with your actual OpenWeatherMap API key")
        print("Get your free API key at: https://openweathermap.org/api")
        return
    
    try:
        # Prepare the API request
        params = {
            'q': city,
            'appid': API_KEY,
            'units': 'metric'  # Use Celsius for temperature
        }
        
        print(f"Getting weather information for {city}...")
        
        # Make the API request
        response = requests.get(BASE_URL, params=params)
        
        # Check if request was successful
        if response.status_code == 200:
            # Parse the JSON response
            weather_data = response.json()
            
            # Print the raw JSON (for learning purposes)
            print("\n=== RAW JSON RESPONSE ===")
            print(json.dumps(weather_data, indent=2))
            
            # Extract and display key information
            print(f"\n=== WEATHER SUMMARY FOR {city.upper()} ===")
            print(f"Temperature: {weather_data['main']['temp']}°C")
            print(f"Feels like: {weather_data['main']['feels_like']}°C")
            print(f"Description: {weather_data['weather'][0]['description'].title()}")
            print(f"Humidity: {weather_data['main']['humidity']}%")
            print(f"Pressure: {weather_data['main']['pressure']} hPa")
            print(f"Wind Speed: {weather_data['wind']['speed']} m/s")
            
        else:
            print(f"Error: API request failed with status code {response.status_code}")
            print(f"Response: {response.text}")
            
    except requests.exceptions.RequestException as e:
        print(f"Error making API request: {e}")
    except KeyError as e:
        print(f"Error parsing weather data: Missing key {e}")
    except Exception as e:
        print(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()