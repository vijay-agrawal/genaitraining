# -*- coding: utf-8 -*-
from openai import AzureOpenAI
from dotenv import load_dotenv
import os

load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }

client = AzureOpenAI(
    azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    api_key=azure_config["AZURE_OPENAI_API_KEY"],
    api_version=azure_config["AZURE_OPENAI_API_VERSION"]
)
model_name=azure_config["AZURE_OPENAI_MODEL_NAME"]

"""

## Rephrase & Respond

In the Rephrase & Respond method of prompt engineering, we ask the LLM to 
rephrase the original user question to a format that will enable it to 
answer better.

"""

system_message = """
You are a helpful assistant tasked to answer queries on financial information.
"""

"""An extract from the Tesla 2022 10-K statement that will be used as context for this demonstration."""

rephrase_user_message = """
Context:
In 2022, we recognized total revenues of $81.46 billion, respectively, representing an increase of $27.64 billion, compared to the prior year.
We continue to ramp production, build new manufacturing capacity and expand our operations to enable increased deliveries and deployments of our products and further revenue growth.
===

Question:
What was the increase in annual revenue in 2022 compared to 2021?

Using the context presented above, rephrase and expand the above question to help you do better answering.
Maintain all the information in the original question.
Please note that you only have to rephrase the question, do not mention the context.
The context is only presented for your reference.
"""

rephrase_prompt = [
    {'role':'system', 'content': system_message},
    {'role': 'user', 'content': rephrase_user_message}
]

response = client.chat.completions.create(
    model=model_name,
    messages=rephrase_prompt,
    temperature=0
)

rephrased_factual_question = response.choices[0].message.content

print(rephrased_factual_question)

response_user_message = """
Context:
In 2022, we recognized total revenues of $81.46 billion, respectively, representing an increase of $27.64 billion, compared to the prior year.
We continue to ramp production, build new manufacturing capacity and expand our operations to enable increased deliveries and deployments of our products and further revenue growth.
===

Original Question:
What was the increase in annual revenue in 2022 compared to 2021?

Rephrased Question:
What was the difference in total revenues between 2022 and 2021, and how much did it increase in 2022 compared to the previous year?

Given the above context, use your answer for the rephrased question presented above to answer the original question.
Present your final answer in the following format.
Final Answer: <your-final-answer>
"""

response_prompt = [
    {'role':'system', 'content': system_message},
    {'role': 'user', 'content': response_user_message}
]

response = client.chat.completions.create(
    model=model_name,
    messages=response_prompt,
    temperature=0
)

print(response.choices[0].message.content)

"""## Self-consistency

In self-consistency, we generate multiple answers to the same question and pick the answer that is repeated the most across these occurrences. This is particularly valuable for factual questions.
"""

system_message = "You are a helpful assistant tasked to answer queries on financial information."

answers_template = """
Context:
{context}
===
Using the context above generate {num_answers} distinct answers to the following question:
Question:
{question}.

Arrange your answers in numbered bullet points.
"""

"""Here is an extract from the Tesla 2022 10-K statement that will be used as context for this demonstration."""

tesla_annual_report_context ="""
In 2022, we recognized total revenues of $81.46 billion, respectively, representing an increase of $27.64 billion, compared to the prior year.
We continue to ramp production, build new manufacturing capacity and expand our operations to enable increased deliveries and deployments of our products and further revenue growth.
"""

factual_question = "What was the increase in annual revenue in 2022 compared to 2021?"

answers_prompt = [
    {'role':'system', 'content': system_message},
     {'role': 'user', 'content': answers_template.format(
         context=tesla_annual_report_context,
         question=factual_question,
         num_answers=3
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=answers_prompt,
    temperature=0
)

factual_answers = response.choices[0].message.content

print(factual_answers)

consistency_template = """
Here are {num_answers} answers to the question mentioned below:
Question:
{question}
Answers:
{answers}

Observe the answers mentioned above and choose the answer that occurs most.
Present only the most frequent solution in the following format.
Final Answer:
"""

consistency_prompt = [
    {'role':'system', 'content': system_message},
     {'role': 'user', 'content': consistency_template.format(
         num_answers=3,
         question=factual_question,
         answers=factual_answers
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=consistency_prompt,
    temperature=0
)

print(response.choices[0].message.content)

"""## LLM-as-a-Judge

In this method, we use another LLM to rate the performance of the LLM used in the original task (see figure below for an example in case of summarization). This method of using LLMs to evaluate LLMs is usualy referred to as LLM-as-a-judge. When LLMs are used to evaluate output, the system message should clearly define the rubrics used for evaluation and the key aspects of the output that should be evaluated. The advantage of using LLMs as judges is that we do not need human baselines (that are costly to collect), while writing down the rubrics for assessment is usually an easier task.
"""

example_dialogue = """
Dialogue:
#Person1#: Excuse me, could you tell me where physics 403 is? Has it been moved?
#Person2#: OK. Let me check on the computer. Err I'm sorry, but it says here that the class was cancelled. You should have got a notice letter about this.
#Person1#: What? I never got it.
#Person2#: Are you sure? It says on the computer that the letter was sent out to the students a week ago.
#Person1#: Really? I should have got it by now. I wonder if I threw it away with all the junk mail by mistake.
#Person2#: Well, it does happen. Err let me check something. What's your name?
#Person1#: Woodhouse Laura Woodhouse.
#Person2#: OK, Woodhouse. Let me see. Ah, it says here we sent it to your apartment on the Center Street.
#Person1#: Oh, that's my old apartment. I moved out of there a little while ago.
#Person2#: Well, I suppose you haven't changed your mailing address at the administration office.
#Person1#: Yeah, I should have changed it in time.
"""

example_summary = """
Summary:
Laura Woodhouse finds out physics is canceled but she never received the mail. #Person2# finds her mailing address is her old apartment. Laura thinks she should have changed it in time.
"""

rater_system_message = """
You are tasked with rating AI-generated summaries of dialogues based on the given metric.
You will be presented a dialogue and an AI generated summary of the dialogue as the input.
In the input, the dialogue will begin with ###Dialogue while the AI generated summary will begin with ###Summary.

Evaluation criteria:
The task is to judge the extent to which the metric is followed by the summary.
1 - The metric is not followed at all
2 - The metric is followed only to a limited extent
3 - The metric is followed to a good extent
4 - The metric is followed mostly
5 - The metric is followed completely

Metric:
The summary should cover all the aspects that are majorly being discussed in the dialogue.

Instructions:
1. First write down the steps that are needed to evaluate the summary as per the metric.
2. Give a step-by-step explanation if the summary adheres to the metric considering the dialogues as the input.
3. Next, evaluate the extent to which the metric is followed.
4. Use the previous information to rate the summary using the evaluaton criteria and assign a score.
"""

rater_model = model_name # "gpt-4"

"""Notice how the rubric is clearly defined. Also the metric used to judge the output is clearly delineated. This prompt can be readily adapted to create multiple raters,e ach focusing on one metric."""

rater_user_message = f"""
###Dialogue
{example_dialogue}

###Summary
{example_summary}
"""

rater_prompt = [
    {'role': 'system', 'content': rater_system_message},
    {'role': 'user', 'content': rater_user_message}
]

response = client.chat.completions.create(
    model=rater_model,
    messages=rater_prompt
)

print(response.choices[0].message.content)

"""## Tree-of-Thought

Tree-of-thought prompting is a generalization of chain-of-thought prompting where the model is prompted to take multiple reasoning paths. This forces the LLM into a deliberate reasoning mode.
"""

solutions_template = """
Generate {num_solutions} distinct solutions for the following problem:
Problem:
{problem}.
--

Consider the following factors in coming up with your solutions.
Factors:
{factors}

Present the solutions in numbered bullet points. Present only the solutions.
"""

climate_problem = "Reduce the impact of climate change on the occurrence of extreme events in the Earth's atmosphere."

climate_factors = """
1. Renewable Energy Transition
2. Reforestation
3. Sustainable Agricultural Practises
4. Carbon capture and storage
5. Climate-resilient infrastructure
6. Circular economy practises
"""

solutions_prompt = [
     {
         'role': 'user',
         'content': solutions_template.format(
             num_solutions=3,
             problem=climate_problem,
             factors=climate_factors
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=solutions_prompt,
    temperature=0
)

print(response.choices[0].message.content)

climate_solutions = response.choices[0].message.content

evaluation_template = """
For the following problem: {problem}, evaluate each solution in the following proposed solutions: \n{solutions}\n.
Analyze pros, cons, feasibility, and probability of success for each solution.
Present your evaluations of each solutions.
"""

evaluations_prompt = [
     {
         'role': 'user',
         'content': evaluation_template.format(
             problem=climate_problem,
             solutions=climate_solutions
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=evaluations_prompt,
    temperature=0
)

climate_proposal_evaluations = response.choices[0].message.content

print(climate_proposal_evaluations)

ranking_template = """
For the following problem: {problem}, rank the solutions presented in the following evaluations: \n{evaluations}\n.
Pick most promising solution and present implementation strategies and methods to handle potential obstacles for this solution.
"""

ranking_prompt = [
     {
         'role': 'user',
         'content': ranking_template.format(
             problem=climate_problem,
             evaluations=climate_proposal_evaluations
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=ranking_prompt,
    temperature=0
)

climate_proposal_rankings = response.choices[0].message.content

print(climate_proposal_rankings)