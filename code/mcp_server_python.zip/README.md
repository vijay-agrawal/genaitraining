# MCP Server (Python) Demo Setup

## Python Dependencies

We will use Python, so install the python depenndencies

### Core dependencies

```sh
pip install mcp requests python-dotenv
```

### For LLM integrations

```sh
pip install openai          # For OpenAI GPT models
pip install anthropic       # For Claude models  
pip install "crewai-tools[mcp]" crewai  # For CrewAI integration
```

> **Note:** There's no official Python MCP SDK yet, so we implement JSON-RPC manually.

## Create weather MCP Server

See weather_mcp_server.py for the implementation

## Test the MCP Server

Note that there is no http port or anything that the MCP server will listen on
it will be invoked by the client/test as needed using Inter process communication/pipe mechanism

Review and run test_mcp_server.py (or weather_app.py)



