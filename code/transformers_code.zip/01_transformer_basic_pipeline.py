# If needed, install dependencies:
# !pip install transformers torch

from transformers import pipeline

# 1. Create a text-generation pipeline using GPT-2
generator = pipeline(
    "text-generation",
    model="gpt2",              # Try "gpt2-medium" or "gpt2-large" for bigger models
)

# 2. Provide a prompt to seed the generation
prompt = "The best cricketer in the world is "

# 3. Generate multiple completions using different sampling options
outputs = generator(
    prompt,
    max_length=50,            # Total length of the generated sequence (prompt + generation)
    num_return_sequences=3,   # Number of distinct completions to produce
    temperature=0.7,          # Controls creativity; higher = more random completions
    top_p=0.9,                # Nucleus sampling hyperparameter
    top_k=50,                 # Restrict token sampling to the top_k most likely tokens
    do_sample=True,           # Enable sampling instead of greedy decoding
)

# 4. Print out the generated sequences
for i, completion in enumerate(outputs):
    print(f"=== Generated Output {i+1} ===")
    print(completion["generated_text"])
    print()

# play with different settings above:
#
# num_return_sequences: How many different completions you want for a single prompt.
#
# max_length: The maximum number of tokens (including the prompt) in the generated output.
#
# temperature: Controls how “creative” or “risky” the generation is. 
# A higher value produces more varied (but potentially less coherent) text.
#
# top_p (nucleus sampling): Only tokens whose cumulative probability adds up to this value are considered. 
# For example, top_p=0.9 includes all tokens accounting for 90% of the probability mass.
#
# top_k: Limits the candidate tokens to the top k most likely tokens for each prediction step.
#
# do_sample=True: Enables stochastic sampling (i.e., random draw) from the model’s probability distribution, 
# rather than using greedy decoding (which always picks the single most likely next token).
#