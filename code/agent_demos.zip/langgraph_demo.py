import streamlit as st
from langchain.llms import AzureOpenAI
from langchain.agents import Tool
from langgraph.graph import Graph, Node
from langgraph.agent import Agent

###############################################################################
# 1) HARDCODED FUNCTIONS (TOOLS)
###############################################################################
def route_nurse(symptoms: str) -> str:
    """Decide which nurse based on the patient's symptoms."""
    text = symptoms.lower()
    if any(word in text for word in ["heart", "chest", "cardiac"]):
        return "heart nurse"
    elif any(word in text for word in ["ear", "nose", "throat", "ent"]):
        return "ENT nurse"
    elif any(word in text for word in ["bone", "joint", "ortho"]):
        return "ortho nurse"
    elif any(word in text for word in ["child", "kid", "pediatric"]):
        return "pediatric nurse"
    else:
        return "pediatric nurse"  # default routing for demo

def measure_vitals(nurse_specialty: str) -> str:
    """Return some vitals specific to the nurse's specialty."""
    if "heart" in nurse_specialty:
        return "Blood Pressure=130/80, Pulse=80 bpm"
    elif "ENT" in nurse_specialty:
        return "Temperature=99.5F, Ears=No infection, Throat=Slight redness"
    elif "ortho" in nurse_specialty:
        return "Limb Movement=Normal, X-Ray=Clear, PainScale=4"
    else:  # pediatric
        return "Temperature=100.1F, Weight=16kg, GrowthPercentile=50th"

def route_doctor(nurse_specialty: str) -> str:
    """Decide which doctor to see based on the nurse's specialty."""
    # For demo, we just do a direct mapping.
    if "heart" in nurse_specialty:
        return "heart doctor"
    elif "ENT" in nurse_specialty:
        return "ENT doctor"
    elif "ortho" in nurse_specialty:
        return "ortho doctor"
    else:
        return "pediatric doctor"

def doctor_prescribe(doctor_specialty_and_vitals: str) -> str:
    """Doctor writes prescription based on specialty and vitals."""
    if "heart doctor" in doctor_specialty_and_vitals:
        return "Atenolol 50mg daily"
    elif "ENT doctor" in doctor_specialty_and_vitals:
        return "Nasal spray and antibiotics"
    elif "ortho doctor" in doctor_specialty_and_vitals:
        return "Pain reliever and gentle exercises"
    else:
        return "Pediatric cough syrup"
    
def pharmacist_fill(prescription: str) -> str:
    """Pharmacist finalizes the prescription."""
    return f"Prescription Provided: {prescription}. Patient can pick it up at Pharmacy."

###############################################################################
# 2) TOOLS -> Each Agent uses whichever tool(s) make sense
###############################################################################
attendant_tool = Tool(
    name="Attendant Routing",
    func=route_nurse,
    description="Routes patient to the correct nurse based on symptoms."
)

nurse_tool = Tool(
    name="Nurse Vitals",
    func=measure_vitals,
    description="Measures relevant vitals based on nurse specialty."
)

doctor_route_tool = Tool(
    name="Doctor Routing",
    func=route_doctor,
    description="Routes patient to the correct doctor based on nurse's specialty."
)

doctor_prescribe_tool = Tool(
    name="Doctor Prescription",
    func=doctor_prescribe,
    description="Doctor writes prescription after reviewing vitals."
)

pharmacist_tool = Tool(
    name="Pharmacist",
    func=pharmacist_fill,
    description="Pharmacist finalizes and provides prescription."
)

###############################################################################
# 3) LLM WITH A SYSTEM PROMPT
###############################################################################
#  In practice, replace with valid Azure OpenAI credentials.
#  The key idea is to show that we’re using Azure + LangChain + LangGraph.
system_prompt = """You are a hospital workflow system (Attendant, Nurses, Doctors, Pharmacist).
You route patients based on their symptoms, measure their vitals, and produce prescriptions.
You have these specialities:
- Nurses: Heart, ENT, Ortho, Pediatric
- Doctors: Heart, ENT, Ortho, Pediatric
- 1 Pharmacist.
Follow the step-by-step roles accurately. Return final prescriptions at the end."""

llm = AzureOpenAI(
    deployment_name="YOUR_DEPLOYMENT_NAME",
    model_name="gpt-4",
    openai_api_version="2023-03-15-preview",
    openai_api_base="https://YOUR_ENDPOINT_NAME.openai.azure.com/",
    openai_api_key="YOUR_API_KEY",
    temperature=0,
    system_prompt=system_prompt
)

###############################################################################
# 4) AGENTS (Attendant, Nurse, Doctor, Pharmacist)
#    For demo simplicity, we create 4 "roles" as separate Agents
###############################################################################
attendant_agent = Agent(llm=llm, tools=[attendant_tool])
nurse_agent = Agent(llm=llm, tools=[nurse_tool])
doctor_agent = Agent(llm=llm, tools=[doctor_route_tool, doctor_prescribe_tool])
pharmacist_agent = Agent(llm=llm, tools=[pharmacist_tool])

###############################################################################
# 5) BUILD THE WORKFLOW GRAPH
###############################################################################
graph = Graph()

# Create nodes
graph.add_node("Attendant", Node(attendant_agent, prompt="Identify the right nurse."))
graph.add_node("Nurse", Node(nurse_agent, prompt="Measure vitals for your specialty."))
graph.add_node("Doctor", Node(doctor_agent, prompt="Route to correct doctor and prescribe."))
graph.add_node("Pharmacist", Node(pharmacist_agent, prompt="Finalize prescription."))

# Connect them in order
graph.add_edge("Attendant", "Nurse")
graph.add_edge("Nurse", "Doctor")
graph.add_edge("Doctor", "Pharmacist")

###############################################################################
# 6) STREAMLIT APP: Simple Chat-like Interface
###############################################################################
st.title("Hospital Multi-Agent Demo")

# Ask user for symptoms
user_symptoms = st.text_input("Enter your symptoms here:", "")

if st.button("Get Prescription"):
    if not user_symptoms.strip():
        st.warning("Please enter some symptoms.")
    else:
        # Run the multi-agent workflow with the user's symptoms
        final_output = graph.run(user_symptoms)
        st.write("### Final Output:")
        st.write(final_output)
