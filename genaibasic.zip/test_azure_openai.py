import os
from openai import AzureOpenAI
from dotenv import load_dotenv

load_dotenv()

prompt = 'who is the prime minister of India?'

client = AzureOpenAI(
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION")
)
model_name=os.getenv("AZURE_OPENAI_MODEL_NAME")

try:
    response = client.chat.completions.create(
    model=model_name,
    messages=[
        {"role": "system", "content": 
            """ You are a expert in cricket game. 
            Answer only cricket related questions. 
            Do not answer any other question"""
            },
        {"role": "user", "content": prompt}
    ] )
    #print (response)
    answer = response.choices[0].message.content.strip()
except Exception as e:
    print(e) # Log error and continue
    
print("Prompt:")
print(prompt)
print("Response from LLM:")
print(answer)
