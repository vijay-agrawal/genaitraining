# Define function get_weather that takes in location as input parameter and
# returns the weather as a string
def get_weather(location):
    return f"Sunny, 25°C in {location}"

# Define function get_stock_price that takes in company nanme as input parameter and
# returns the stock price as a numeric value
def get_stock_price(company_name):
    return f"{company_name} stock: Rs 1150.75"

def main():
    print(get_weather("Mumbai"))
    print(get_stock_price("TCS"))

if __name__ == "__main__":
    main()