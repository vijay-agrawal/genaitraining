import os
import openai
import streamlit as st
from dotenv import load_dotenv
from openai import AzureOpenAI

# Load environment variables from .env
load_dotenv()

# Set page config
st.set_page_config(page_title="Mudra Saarthi", page_icon="💬")
st.title("Welcome to Mudra Saarthi")

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }

# Initialize Azure OpenAI client
client = AzureOpenAI(
    azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    api_key=azure_config["AZURE_OPENAI_API_KEY"],
    api_version=azure_config["AZURE_OPENAI_API_VERSION"]
)

# Define a system prompt that returns a welcome message + instructions.
system_prompt = """
You are a loan approval officer, your task is to determine whether a loan application should be approved or not based on the applicant’s responses to five key questions.

Here is how the process will work:

You will ask the applicant the following five questions:
What is your current employment status?
What is your monthly income?
How long have you been employed at your current job?
What is your credit score?
Do you have any outstanding debts or loans?
Based on the applicant’s responses, you will assign a score from 0 to 100, with each response contributing to the total score.
Employment status: Stable employment (20 points), Contract/Freelance (10 points), Unemployed (0 points)
Monthly income: Above $5,000 (20 points), $2,500 - $5,000 (15 points), Below $2,500 (5 points)
Employment duration: More than 3 years (20 points), 1-3 years (10 points), Less than 1 year (5 points)
Credit score: Above 750 (20 points), 600-750 (15 points), Below 600 (5 points)
Outstanding debts/loans: None (20 points), Up to $10,000 (10 points), More than $10,000 (5 points)
The total score will be out of 100. The cutoff score for loan approval is 70. If the applicant’s total score is 70 or above, the loan will be approved. If the score is below 70, the loan will be denied.
Just ask plain questions do not give choices and do not mention points in the question. 
Validate the response from the user. Credit score should be between 200 and 800. If user inputs invalid answer, guide the user and ask him to enter again.
After each response from the user, mention mention the points and reasoning for it.
Please start by greeting the user and introducing yourself, then proceed with asking the applicant the first question.
"""
# Called when user submits a prompt:
# 1) Appends the user input to history
# 2) Calls Azure OpenAI
# 3) Appends the assistant response
# 4) Resets the text input
def submit():
    user_input = st.session_state.user_input
    if user_input.strip():
        st.session_state.messages.append({"role": "user", "content": user_input})
        response = client.chat.completions.create(
            model=azure_config["AZURE_OPENAI_MODEL_NAME"],
            messages=st.session_state.messages
        )
        assistant_output = response.choices[0].message.content
        st.session_state.messages.append({"role": "assistant", "content": assistant_output})
    
    # Clear the text input for the next user prompt
    st.session_state.user_input = ""

# Initialize session state for storing the conversation
if "messages" not in st.session_state:
    st.session_state.messages = []

# If it's the first run, call the system prompt and store the welcome message
if not st.session_state.messages:
    response = client.chat.completions.create(
        model=azure_config["AZURE_OPENAI_MODEL_NAME"],
        messages=[{"role": "system", "content": system_prompt}]
    )
    system_output = response.choices[0].message.content
    st.session_state.messages.append({"role": "system", "content": system_prompt})
    st.session_state.messages.append({"role": "assistant", "content": system_output})

    ## parse the response and write code to process this further as needed

# Define custom labels for roles
role_labels = {
    "system": "System",
    "user": "You",
    "assistant": "Mudra Saarthi"  # <-- Custom label for assistant messages
}

# Display messages from the history/previous conversations
for msg in st.session_state.messages:
    # Only display user and assistant messages
    if msg["role"] in ["user", "assistant"]:    
        role = role_labels.get(msg["role"], msg["role"].capitalize())
        st.markdown(f"**{role}:** {msg['content']}")

# Text input with on_change callback
st.text_input(
    "Your message:",
    value="",
    key="user_input",
    on_change=submit
)