# pip install spacy && python -m spacy download en_core_web_sm
import spacy; 

model=spacy.load("en_core_web_sm")

doc="Apple is looking at buying U.K. startup for $1 billion"

ner_results=model(doc)

for e in ner_results.ents:
    print([e.text, e.label_])
