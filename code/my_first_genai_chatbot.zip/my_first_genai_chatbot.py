# Import os to handle environment variables
#
# To run this app
# 
# streamlit run <path to this file, for example, rag\streamlit_app_basic.py>
#
import os
from dotenv import load_dotenv
import streamlit as st

load_dotenv()

st.subheader("<Your Name>'s AI chatbot")

def generate_response(input_text):
        
        # 1. Access Gen AI Model from AWS Bedrock service
        # 2. Pass the user text to the AWS Bedrock API 
        # 3. Get the response from the Gen AI Model
        # 4. Print it on the output
        st.info("<response>")  # Display the response content

user_question = st.text_input("Ask any question. Press enter to submit", key="user_question")
if user_question:
    generate_response(user_question)