# ============================================================
# Import required libraries: regex for text matching, PyPDF2 for PDF processing,
# and GraphDatabase from neo4j for database connectivity.
# ============================================================
import re
import PyPDF2
from neo4j import GraphDatabase

# ============================================================
# Set the absolute path to the PDF file to be processed.
# ============================================================
pdf_path = "/Users/riyabangera/Desktop/genaicode/Disease treatments.pdf"

# ============================================================
# Define a function to extract all text from the PDF file.
# ============================================================
def extract_text_from_pdf(pdf_path):
    text = ""
    with open(pdf_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + "\n"
    return text

# ============================================================
# Define a function to extract relationships using a block-based approach.
# The function searches for patterns where a disease title is followed by an "Overview:" block,
# and then a block that includes medication or treatment information.
# ============================================================
def extract_relationships_block_based(text):
    """
    Try splitting the text into blocks (by double newlines) and then look for a pattern
    where a block starting with "Overview:" is preceded by a disease title, and a subsequent
    block contains "Common Medications and Side E ects:" or "Common Treatments and Side E ects:".
    """
    relationships = []
    blocks = [b.strip() for b in text.split("\n\n") if b.strip()]
    for i, block in enumerate(blocks):
        if block.startswith("Overview:") and i > 0:
            disease = blocks[i-1]
            med_section = None
            for j in range(i, len(blocks)):
                if ("Common Medications and Side Effects:" in blocks[j] or
                    "Common Treatments and Side Effects:" in blocks[j]):
                    med_section = blocks[j]
                    
                    break
            if med_section:
                drug_pattern = re.compile(r"e\.g\.\s*([^)]+?)(?:[\):]|$)", re.IGNORECASE)
                matches = drug_pattern.findall(med_section)
                for match in matches:
                    drugs = [drug.strip() for drug in match.split(",")]
                    for drug in drugs:
                        if drug:
                            relationships.append((drug, disease))
    return relationships

# ============================================================
# Define a function to extract relationships using a line-based approach.
# This function processes the text line by line to find disease names and their corresponding medications/treatments.
# ============================================================
def extract_relationships_line_based(text):
    """
    Process the text line by line. When a line starting with "Overview:" is found, assume the previous
    non-empty line is the disease name. Then, when encountering a line that starts with " Common Medications"
    or " Common Treatments", look in subsequent lines for "e.g." patterns and extract the drug names.
    """
    lines = text.splitlines()
    relationships = []
    current_disease = None
    for i, line in enumerate(lines):
        line = line.strip()
        if not line:
            continue
        # If we encounter "Overview:", take the previous non-empty line as the disease name.
        if line.startswith("Overview:"):
            j = i - 1
            while j >= 0:
                prev_line = lines[j].strip()
                if prev_line:
                    # Filter out generic header lines.
                    if "Global Diseases" not in prev_line and "Top" not in prev_line:
                        current_disease = prev_line
                    break
                j -= 1
        # When we hit the medications/treatments header...
        if line.startswith(" Common Medications") or line.startswith(" Common Treatments"):
            j = i + 1
            while j < len(lines):
                next_line = lines[j].strip()
                if not next_line or next_line.startswith("Overview:") or next_line.startswith(" "):
                    break
                # Look for "e.g." patterns in the line.
                eg_matches = re.findall(r"e\.g\.\s*([^):]+)", next_line, re.IGNORECASE)
                for match in eg_matches:
                    drugs = [d.strip() for d in match.split(",")]
                    for drug in drugs:
                        if current_disease and drug:
                            relationships.append((drug, current_disease))
                j += 1
    return relationships

# ============================================================
# Define a function to extract relationships from text.
# It first attempts the block-based approach, and if no relationships are found,
# it falls back to the line-based approach.
# ============================================================
def extract_relationships(text):
    # First try the block-based approach.
    relationships = extract_relationships_block_based(text)
    if not relationships:
        print("Block-based approach found no relationships, trying line-based approach.")
        relationships = extract_relationships_line_based(text)
    return relationships

# ============================================================
# Define a function to store the extracted relationships in a Neo4j database.
# This function connects to the database and creates nodes for drugs and diseases,
# and then creates relationships between them.
# ============================================================
def store_relationships_in_neo4j(relationships, uri, user, password):
    driver = GraphDatabase.driver(uri, auth=(user, password))
    
    def add_relationship(tx, drug, disease):
        print(f"🧪 Storing: Drug='{drug}', Disease='{disease}'")
        query = """
        MERGE (d:Drug {name: $drug})
        MERGE (di:Disease {name: $disease})
        MERGE (d)-[:TREATED_FOR]->(di)
        """
        tx.run(query, drug=drug, disease=disease)
    
    with driver.session() as session:
        for drug, disease in relationships:
            if drug and disease:  # Add this check to avoid empty entries
                session.write_transaction(add_relationship, drug.strip(), disease.strip())
    
    driver.close()

# ============================================================
# Define the main function which ties together all previous functions:
# 1. Extract text from the PDF.
# 2. Extract relationships from the text.
# 3. Store the relationships in the Neo4j database.
# ============================================================
def main():
    print("Extracting text from PDF...")
    text = extract_text_from_pdf(pdf_path)
    
    print("Extracting relationships from text...")
    relationships = extract_relationships(text)
    
    if not relationships:
        print("No relationships found in the document.")
        return
    
    # Update Neo4j connection details as needed.
    neo4j_uri = "neo4j+s://d591a908.databases.neo4j.io"
    neo4j_user = "neo4j"
    neo4j_password = "jT9H3c6GL1f6ffkbNe8JpOpYoz9vxrFDhyZ60ZPZQQ0"  
    
    print("Storing relationships in Neo4j...")
    store_relationships_in_neo4j(relationships, neo4j_uri, neo4j_user, neo4j_password)
    print("Indexing complete.")

# ============================================================
# If this script is run directly, execute the main function.
# ============================================================
if __name__ == '__main__':
    main()

