import sys
import json
import os
import inspect
import requests
import yfinance as yf
from datetime import datetime
from dotenv import load_dotenv
import streamlit as st
from openai import AzureOpenAI
from langchain.callbacks import get_openai_callback

# Load environment variables
load_dotenv()

# Configure Azure OpenAI settings
azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
}
OPENWEATHERMAP_API_KEY = os.getenv("OPENWEATHERMAP_API_KEY")

# App title and description
st.title("Multipurpose Assistant")
st.markdown("Ask me about weather or stock prices!")

# Initialize chat history in session state if it doesn't exist
if "messages" not in st.session_state:
    st.session_state.messages = []

# Display chat history
for message in st.session_state.messages:
    with st.chat_message(message["role"]):
        st.markdown(message["content"])

# Function to get weather data
def get_weather(location, days=1, detailed=False):
    """
    Get weather forecast for a location.
    
    Args:
        location (str): City or location name
        days (int, optional): Number of days to forecast. Defaults to 1.
        detailed (bool, optional): Whether to return detailed forecast. Defaults to False.
        
    Returns:
        dict: Weather forecast data
    """
    print(f"Getting weather for location: {location}, days: {days}, detailed: {detailed}")
    
    # Get latitude and longitude from location name
    geo_url = f"http://api.openweathermap.org/geo/1.0/direct?q={location}&limit=1&appid={OPENWEATHERMAP_API_KEY}"
    geo_response = requests.get(geo_url)
    
    if geo_response.status_code != 200:
        return f"Error: Could not retrieve location data. Status code: {geo_response.status_code}"
    
    geo_data = geo_response.json()
    if not geo_data:
        return f"Error: Location '{location}' not found."
    
    latitude = geo_data[0]['lat']
    longitude = geo_data[0]['lon']
    
    # Get weather forecast data
    weather_url = f"http://api.openweathermap.org/data/2.5/forecast?lat={latitude}&lon={longitude}&appid={OPENWEATHERMAP_API_KEY}&units=metric"
    weather_response = requests.get(weather_url)
    
    if weather_response.status_code != 200:
        return f"Error: Could not retrieve weather data. Status code: {weather_response.status_code}"
    
    weather_data = weather_response.json()
    
    # Calculate how many forecast entries to include based on days requested
    entries_per_day = 8  # 8 entries of 3-hour intervals = 24 hours
    total_entries = min(entries_per_day * days, len(weather_data['list']))
    
    # Extract forecast data for requested days
    forecasts = []
    for forecast in weather_data['list'][:total_entries]:
        forecast_time = forecast['dt_txt']
        description = forecast['weather'][0]['description']
        rain_probability = forecast.get('pop', 0) * 100  # Probability of precipitation
        
        forecasts.append({
            'time': forecast_time,
            'description': description,
            'rain_probability': rain_probability,
            'temp': forecast['main']['temp'],
            'humidity': forecast['main']['humidity'],
            'wind_speed': forecast['wind']['speed']
        })
    
    # Return formatted weather data
    result = {
        'location': location,
        'forecast': forecasts
    }
    
    # Include raw data if detailed is True
    if detailed:
        result['raw_data'] = json.dumps(weather_data, indent=2)
    
    return result

# Function to get stock information
def get_stock_price(symbol):
    """
    Get the latest stock price and information for a given ticker symbol.
    
    Args:
        symbol (str): Stock ticker symbol (e.g., 'AAPL' for Apple)
        
    Returns:
        dict: Stock information including price, change, and company details
    """
    try:
        # Get stock information using yfinance
        stock = yf.Ticker(symbol)
        
        # Get latest price information
        stock_info = stock.info
        
        # Get historical data for today
        today = datetime.now().strftime('%Y-%m-%d')
        hist = stock.history(period="2d")
        
        if hist.empty:
            return f"Error: No data available for symbol '{symbol}'"
        
        # Calculate change from previous close
        latest_close = hist['Close'].iloc[-1]
        previous_close = hist['Close'].iloc[0] if len(hist) > 1 else latest_close
        change = latest_close - previous_close
        change_percent = (change / previous_close) * 100 if previous_close else 0
        
        # Prepare result
        result = {
            'symbol': symbol,
            'company_name': stock_info.get('shortName', 'N/A'),
            'latest_price': latest_close,
            'currency': stock_info.get('currency', 'USD'),
            'change': change,
            'change_percent': change_percent,
            'previous_close': previous_close,
            'market_cap': stock_info.get('marketCap', 'N/A'),
            'volume': hist['Volume'].iloc[-1] if 'Volume' in hist else 'N/A',
            'exchange': stock_info.get('exchange', 'N/A'),
            'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        return result
    
    except Exception as e:
        return f"Error: Could not retrieve stock information for '{symbol}'. {str(e)}"

# Function to get company information
def get_company_info(symbol):
    """
    Get detailed information about a company by its stock ticker symbol.
    
    Args:
        symbol (str): Stock ticker symbol (e.g., 'AAPL' for Apple)
        
    Returns:
        dict: Company information including business summary, sector, industry, etc.
    """
    try:
        # Get stock information using yfinance
        stock = yf.Ticker(symbol)
        info = stock.info
        
        # Extract company information
        company_info = {
            'symbol': symbol,
            'name': info.get('shortName', 'N/A'),
            'long_name': info.get('longName', 'N/A'),
            'sector': info.get('sector', 'N/A'),
            'industry': info.get('industry', 'N/A'),
            'employees': info.get('fullTimeEmployees', 'N/A'),
            'website': info.get('website', 'N/A'),
            'business_summary': info.get('longBusinessSummary', 'N/A'),
            'country': info.get('country', 'N/A'),
            'city': info.get('city', 'N/A'),
            'phone': info.get('phone', 'N/A'),
            'ceo': info.get('companyOfficers', [{}])[0].get('name', 'N/A') if info.get('companyOfficers') else 'N/A'
        }
        
        return company_info
    
    except Exception as e:
        return f"Error: Could not retrieve company information for '{symbol}'. {str(e)}"

# Define all available functions for the agent
available_functions = {
    "get_weather": get_weather,
    "get_stock_price": get_stock_price,
    "get_company_info": get_company_info
}

# Function to create function definitions for the LLM
def get_function_definitions():
    function_definitions = []
    
    for func_name, func in available_functions.items():
        # Get the function signature
        sig = inspect.signature(func)
        
        # Get the function docstring
        doc = func.__doc__ or f"Function to {func_name.replace('_', ' ')}"
        
        # Build parameter definitions
        parameters = {
            "type": "object",
            "properties": {},
            "required": []
        }
        
        for param_name, param in sig.parameters.items():
            # Skip *args and **kwargs
            if param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
                continue
                
            # Get parameter type from annotation or default to string
            param_type = "string"
            if param.annotation != inspect.Parameter.empty:
                if param.annotation == int:
                    param_type = "integer"
                elif param.annotation == float:
                    param_type = "number"
                elif param.annotation == bool:
                    param_type = "boolean"
            
            # Get default value
            has_default = param.default != inspect.Parameter.empty
            default_value = param.default if has_default else None
            
            # Get parameter description from docstring
            param_desc = f"Parameter {param_name} for function {func_name}"
            
            # Add parameter to properties
            parameters["properties"][param_name] = {
                "type": param_type,
                "description": param_desc
            }
            
            # Add default value if exists
            if has_default and default_value is not None:
                parameters["properties"][param_name]["default"] = default_value
            
            # Add to required list if no default value
            if not has_default:
                parameters["required"].append(param_name)
        
        # Create function definition
        function_def = {
            "name": func_name,
            "description": doc,
            "parameters": parameters
        }
        
        function_definitions.append(function_def)
    
    return function_definitions

# Function to execute function call from LLM
def execute_function_call(function_call):
    """Execute a function call based on LLM response"""
    function_name = function_call.name
    
    # Parse arguments
    try:
        arguments = json.loads(function_call.arguments)
    except json.JSONDecodeError:
        return f"Error: Invalid function arguments format: {function_call.arguments}"
    
    # Check if function exists
    if function_name not in available_functions:
        return f"Error: Function '{function_name}' not found."
    
    # Get the function
    func = available_functions[function_name]
    
    # Execute the function with the provided arguments
    try:
        result = func(**arguments)
        return result
    except Exception as e:
        return f"Error executing function '{function_name}': {str(e)}"

# Function to format function result for the LLM
def format_function_result(function_name, result):
    """Format the result of a function call to be presented to the LLM"""
    if isinstance(result, str) and "Error" in result:
        return result
    
    if function_name == "get_weather":
        # Format weather data as a readable summary
        weather_summary = f"Weather forecast for {result['location']}:\n\n"
        
        for forecast in result['forecast']:
            weather_summary += f"- {forecast['time']}: {forecast['description'].capitalize()}, {forecast['temp']}°C, Rain probability: {forecast['rain_probability']}%\n"
        
        return weather_summary
    
    elif function_name == "get_stock_price":
        # Format stock price data
        change_symbol = "🔺" if result['change'] >= 0 else "🔻"
        price_summary = f"Stock information for {result['company_name']} ({result['symbol']}):\n\n"
        price_summary += f"- Latest Price: {result['latest_price']:.2f} {result['currency']}\n"
        price_summary += f"- Change: {change_symbol} {abs(result['change']):.2f} ({result['change_percent']:.2f}%)\n"
        price_summary += f"- Previous Close: {result['previous_close']:.2f}\n"
        price_summary += f"- Volume: {result['volume']}\n"
        price_summary += f"- Market Cap: {result['market_cap']}\n"
        price_summary += f"- Exchange: {result['exchange']}\n"
        price_summary += f"- As of: {result['timestamp']}\n"
        
        return price_summary
    
    elif function_name == "get_company_info":
        # Format company information
        company_summary = f"Company information for {result['name']} ({result['symbol']}):\n\n"
        company_summary += f"- Full Name: {result['long_name']}\n"
        company_summary += f"- Sector: {result['sector']}\n"
        company_summary += f"- Industry: {result['industry']}\n"
        company_summary += f"- Employees: {result['employees']}\n"
        company_summary += f"- Country: {result['country']}\n"
        company_summary += f"- CEO: {result['ceo']}\n\n"
        company_summary += f"Business Summary:\n{result['business_summary']}\n"
        
        return company_summary
    
    else:
        # For any other functions, just convert to string
        return str(result)

# Function to generate response using Azure OpenAI
def generate_response(input_text):
    client = AzureOpenAI(
        api_key=azure_config["AZURE_OPENAI_API_KEY"],
        api_version=azure_config["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    )
    
    # Get function definitions
    functions = get_function_definitions()
    
    # System prompt for the multipurpose agent
    system_prompt = """
    You are a helpful assistant that can provide information about weather and stock prices.
    
    You have access to several tools:
    - get_weather: Get weather forecast for a location
    - get_stock_price: Get latest stock price information for a ticker symbol
    - get_company_info: Get detailed information about a company
    
    When handling requests:
    
    For weather queries:
    1. Identify if a location is mentioned. If not, ask for it.
    2. Consider if the user is asking about weather conditions, rain, umbrella needs, etc.
    3. Use the get_weather function to retrieve weather data.
    4. Provide a helpful response based on the forecast.
    
    For stock/company queries:
    1. Identify the stock ticker symbol. If only a company name is mentioned, try to determine the correct symbol.
    2. Use the appropriate function to get stock prices or company information.
    3. Provide a concise summary of the important financial information.
    
    Always respond in a helpful, informative manner. If you're uncertain about anything, ask clarifying questions.
    """
    
    # First API call to determine if we need to call a function
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": input_text}
    ]
    
    # Add chat history for context
    for msg in st.session_state.messages[-4:]:  # Include up to last 4 messages for context
        messages.append({"role": msg["role"], "content": msg["content"]})
    
    # Make initial completion call to determine if we need to call functions
    initial_response = client.chat.completions.create(
        model=azure_config["AZURE_OPENAI_MODEL_NAME"],
        messages=messages,
        functions=functions,
        temperature=0.7
    )
    
    # Check if the model wants to call a function
    if initial_response.choices[0].finish_reason == 'function_call':
        # Get function call information
        function_call = initial_response.choices[0].message.function_call
        
        # Execute the function
        function_result = execute_function_call(function_call)
        
        # Format the function result
        formatted_result = format_function_result(function_call.name, function_result)
        
        # Add the function call and result to messages
        messages.append({
            "role": "assistant",
            "content": None,
            "function_call": {
                "name": function_call.name,
                "arguments": function_call.arguments
            }
        })
        
        messages.append({
            "role": "function",
            "name": function_call.name,
            "content": formatted_result
        })
        
        # Make a final completion call with the function result
        final_response = client.chat.completions.create(
            model=azure_config["AZURE_OPENAI_MODEL_NAME"],
            messages=messages,
            temperature=0.7
        )
        
        response = final_response.choices[0].message.content
    else:
        # Model didn't call function, maybe asking for clarification
        response = initial_response.choices[0].message.content
    
    return response

# User input via chat interface
if prompt := st.chat_input("Ask me about weather or stocks..."):
    # Add user message to chat history
    st.session_state.messages.append({"role": "user", "content": prompt})
    
    # Display user message
    with st.chat_message("user"):
        st.markdown(prompt)
    
    # Generate and display response
    with st.chat_message("assistant"):
        with st.spinner("Thinking..."):
            response = generate_response(prompt)
            st.markdown(response)
    
    # Add assistant response to chat history
    st.session_state.messages.append({"role": "assistant", "content": response})

# Sidebar with app information
with st.sidebar:
    st.header("Multipurpose Assistant")
    st.markdown("""
    This assistant can help you with:
    
    **Weather Information**
    - Current weather conditions
    - Weather forecasts
    - Rain predictions
    - Umbrella recommendations
    
    **Stock Market Data**
    - Latest stock prices
    - Price changes and trends
    - Company information
    - Financial metrics
    """)
    
    st.subheader("Sample Questions")
    st.markdown("""
    **Weather Examples:**
    - "Should I bring an umbrella tomorrow in Seattle?"
    - "What's the weather like in Tokyo for the next 3 days?"
    - "Will it rain in New York this weekend?"
    
    **Stock Examples:**
    - "What's the current price of Apple stock?"
    - "How is TSLA performing today?"
    - "Tell me about Microsoft company info"
    """)
    
    # Add requirements note
    st.markdown("---")
    st.markdown("""
    **Requirements:**
    ```
    pip install streamlit openai python-dotenv requests yfinance
    ```
    """)