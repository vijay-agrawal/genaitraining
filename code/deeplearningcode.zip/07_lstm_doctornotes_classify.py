import numpy as np
import pandas as pd
from faker import Faker
import random
from datetime import datetime, timedelta
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, LSTM, Dense, Dropout
import tensorflow as tf

# Create DataFrame
df = pd.read_csv("genaitraining/deeplearning/doctornotes.csv")

# Prepare text preprocessing
tokenizer = Tokenizer(num_words=5000, oov_token="<OOV>")
tokenizer.fit_on_texts(df['note'])

# Convert text to sequences
X = tokenizer.texts_to_sequences(df['note'])
X = pad_sequences(X, maxlen=200, padding='post', truncating='post')

# Encode labels
label_encoder = LabelEncoder()
y = label_encoder.fit_transform(df['diagnosis'])

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Build the model
model = Sequential([
    Embedding(5000, 32, input_length=200),
    LSTM(64, return_sequences=True),
    LSTM(32),
    Dense(16, activation='relu'),
    Dropout(0.5),
    # length of Diagnoses
    Dense(5, activation='softmax')
])

model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])

# Function to predict diagnosis from new note
def predict_diagnosis(note_text):
    # Preprocess the new note
    sequence = tokenizer.texts_to_sequences([note_text])
    padded = pad_sequences(sequence, maxlen=200, padding='post', truncating='post')
    
    # Make prediction
    prediction = model.predict(padded)
    predicted_class = label_encoder.inverse_transform([np.argmax(prediction[0])])
    
    return predicted_class[0], prediction[0][np.argmax(prediction[0])]

# Example usage
print("\nGenerated Dataset Sample:")
print(df.head())

# Train the model
history = model.fit(X_train, y_train,
                   epochs=10,
                   batch_size=8,
                   validation_split=0.2,
                   verbose=1)

# Example prediction
test_note = "Patient John Doe (45y/o) presents with fever, cough, and shortness of breath. Vitals stable."
predicted_diagnosis, confidence = predict_diagnosis(test_note)
print(f"\nTest Note: {test_note}")
print(f"Predicted Diagnosis: {predicted_diagnosis}")
print(f"Confidence: {confidence:.2f}")