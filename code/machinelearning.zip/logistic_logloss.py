import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Simulated Healthcare Data
np.random.seed(42)
n_samples = 100

# Generate random age (20-80 years) and cholesterol level (150-300)
age = np.random.randint(20, 80, n_samples)
cholesterol = np.random.randint(150, 300, n_samples)

# Generate a binary outcome (heart disease: 0 or 1) based on cholesterol levels
heart_disease = (cholesterol > 220).astype(int)  # Simple threshold-based classification

# Create a DataFrame
data = pd.DataFrame({'Age': age, 'Cholesterol': cholesterol, 'Heart Disease': heart_disease})

# Compute Logistic Regression probabilities
z = 0.05 * cholesterol - 10  # Linear function of cholesterol
probabilities = 1 / (1 + np.exp(-z))  # Sigmoid function

# Compute Loss Values
mse_loss = (heart_disease - probabilities) ** 2
log_loss = - (heart_disease * np.log(probabilities) + (1 - heart_disease) * np.log(1 - probabilities))

# Plot MSE vs Log-Loss
plt.figure(figsize=(12, 5))

# MSE Loss Plot
plt.subplot(1, 2, 1)
plt.scatter(probabilities, mse_loss, color='blue', alpha=0.6)
plt.xlabel("Predicted Probability")
plt.ylabel("MSE Loss")
plt.title("MSE Loss Function")
plt.grid(True)

# Log-Loss Plot
plt.subplot(1, 2, 2)
plt.scatter(probabilities, log_loss, color='red', alpha=0.6)
plt.xlabel("Predicted Probability")
plt.ylabel("Log Loss")
plt.title("Log-Loss (Cross-Entropy) Function")
plt.grid(True)

plt.tight_layout()
plt.show()
