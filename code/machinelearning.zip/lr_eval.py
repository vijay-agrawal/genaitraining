import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression, Lasso
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import statsmodels.api as sm

# ------------------------------
# 1. Generate Synthetic Data with an Irrelevant Predictor
# ------------------------------
np.random.seed(42)

n_samples = 100  # Number of observations

# Generate independent variables (X1, X2, X3)
X1 = np.random.uniform(0, 10, size=n_samples)  # Significant feature
X2 = np.random.uniform(0, 10, size=n_samples)  # Significant feature
X3 = np.random.uniform(0, 10, size=n_samples)  # Weak feature

# Introduce a completely **random** (irrelevant) feature
X4 = np.random.uniform(0, 10, size=n_samples)  # Irrelevant (random noise)

# True coefficients (X4 has no true effect)
beta0 = 5       # Intercept
beta1 = 2.5     # Significant coefficient for X1
beta2 = -1.8    # Significant coefficient for X2
beta3 = 0.2     # Weak coefficient for X3
beta4 = 0.0     # No true effect from X4

# Create dependent variable with some noise
noise = np.random.normal(0, 2, size=n_samples)  # Normally distributed noise
y = beta0 + beta1 * X1 + beta2 * X2 + beta3 * X3 + beta4 * X4 + noise

# Combine features into a DataFrame
df = pd.DataFrame({'X1': X1, 'X2': X2, 'X3': X3, 'X4': X4, 'y': y})

# ------------------------------
# 2. Fit OLS Model Using Statsmodels
# ------------------------------
X_all = df[['X1', 'X2', 'X3', 'X4']]  # Features including irrelevant X4
X_all = sm.add_constant(X_all)  # Adds intercept term

# Fit model
ols_model_all = sm.OLS(df['y'], X_all).fit()

# Print summary
print("\nOLS Regression Results Including Irrelevant Predictor (X4):")
print(ols_model_all.summary())

# ------------------------------
# 3. Compute R-Squared for Models With and Without X4
# ------------------------------
X_relevant = df[['X1', 'X2', 'X3']]  # Features excluding X4
X_relevant = sm.add_constant(X_relevant)

# Fit model without X4
ols_model_relevant = sm.OLS(df['y'], X_relevant).fit()

# Extract R-squared values
R2_with_X4 = ols_model_all.rsquared
R2_without_X4 = ols_model_relevant.rsquared

print(f"\nComparison of R-Squared Values:")
print(f" - Model with X4:    R^2 = {R2_with_X4:.4f}")
print(f" - Model without X4: R^2 = {R2_without_X4:.4f}")

# ------------------------------
# 4. Compare the Effect of Adding X4
# ------------------------------
plt.figure(figsize=(8, 5))
plt.bar(["Without X4", "With X4"], [R2_without_X4, R2_with_X4], color=['blue', 'red'])
plt.ylabel("R-Squared Value")
plt.title("Effect of Adding an Irrelevant Predictor (X4)")
plt.ylim([min(R2_without_X4, R2_with_X4) - 0.01, max(R2_without_X4, R2_with_X4) + 0.01])
plt.show()


# Extract F-statistics
F_stat_with_X4 = ols_model_all.fvalue
F_stat_without_X4 = ols_model_relevant.fvalue

# Plot the F-statistic before and after adding X4
plt.figure(figsize=(8, 5))
plt.bar(["Without X4", "With X4"], [F_stat_without_X4, F_stat_with_X4], color=['blue', 'red'])
plt.ylabel("F-Statistic")
plt.title("Effect of Adding an Irrelevant Predictor (X4) on F-Statistic")
plt.ylim([min(F_stat_without_X4, F_stat_with_X4) - 50, max(F_stat_without_X4, F_stat_with_X4) + 50])
plt.show()

# Display values
F_stat_without_X4, F_stat_with_X4