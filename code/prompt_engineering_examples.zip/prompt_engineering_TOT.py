# -*- coding: utf-8 -*-
from openai import AzureOpenAI
from dotenv import load_dotenv
import os

load_dotenv()

azure_config = {
    "AZURE_OPENAI_ENDPOINT": os.getenv("AZURE_OPENAI_ENDPOINT"),
    "AZURE_OPENAI_MODEL_DEPLOYMENT_NAME": os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT_NAME"),
    "AZURE_OPENAI_MODEL_NAME": os.getenv("AZURE_OPENAI_MODEL_NAME"),
    "AZURE_OPENAI_API_KEY": os.getenv("AZURE_OPENAI_API_KEY"),
    "AZURE_OPENAI_API_VERSION": os.getenv("AZURE_OPENAI_API_VERSION")
    }

client = AzureOpenAI(
    azure_endpoint=azure_config["AZURE_OPENAI_ENDPOINT"],
    api_key=azure_config["AZURE_OPENAI_API_KEY"],
    api_version=azure_config["AZURE_OPENAI_API_VERSION"]
)
model_name=azure_config["AZURE_OPENAI_MODEL_NAME"]

"""## Tree-of-Thought

Tree-of-thought prompting is a generalization of chain-of-thought prompting where the model is prompted to take multiple reasoning paths. This forces the LLM into a deliberate reasoning mode.
"""

solutions_template = """
Generate {num_solutions} distinct solutions for the following problem:
Problem:
{problem}.
--

Consider the following factors in coming up with your solutions.
Factors:
{factors}

Present the solutions in numbered bullet points. Present only the solutions.
"""

climate_problem = "Reduce the impact of climate change on the occurrence of extreme events in the Earth's atmosphere."

climate_factors = """
1. Renewable Energy Transition
2. Reforestation
3. Sustainable Agricultural Practises
4. Carbon capture and storage
5. Climate-resilient infrastructure
6. Circular economy practises
"""

solutions_prompt = [
     {
         'role': 'user',
         'content': solutions_template.format(
             num_solutions=3,
             problem=climate_problem,
             factors=climate_factors
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=solutions_prompt,
    temperature=0
)

print(response.choices[0].message.content)

climate_solutions = response.choices[0].message.content

evaluation_template = """
For the following problem: {problem}, evaluate each solution in the following proposed solutions: \n{solutions}\n.
Analyze pros, cons, feasibility, and probability of success for each solution.
Present your evaluations of each solutions.
"""

evaluations_prompt = [
     {
         'role': 'user',
         'content': evaluation_template.format(
             problem=climate_problem,
             solutions=climate_solutions
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=evaluations_prompt,
    temperature=0
)

climate_proposal_evaluations = response.choices[0].message.content

print(climate_proposal_evaluations)

ranking_template = """
For the following problem: {problem}, rank the solutions presented in the following evaluations: \n{evaluations}\n.
Pick most promising solution and present implementation strategies and methods to handle potential obstacles for this solution.
"""

ranking_prompt = [
     {
         'role': 'user',
         'content': ranking_template.format(
             problem=climate_problem,
             evaluations=climate_proposal_evaluations
         )
     }
]

response = client.chat.completions.create(
    model=model_name,
    messages=ranking_prompt,
    temperature=0
)

climate_proposal_rankings = response.choices[0].message.content

print(climate_proposal_rankings)