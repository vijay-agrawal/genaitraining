from gensim.models import Word2Vec

# Sample corpus (tokenized sentences)
sentences = [
    ["the", "dog", "barks", "loudly", "at", "night"],
    ["the", "cat", "meows", "at", "dawn"],
    ["dogs", "and", "cats", "are", "common", "pets"],
    ["the", "king", "and", "queen", "rule", "the", "kingdom"]
]

# Train Word2Vec using Skip-gram
model = Word2Vec(sentences, vector_size=100, window=2, sg=1, min_count=1, workers=4, epochs=10)

# Get word embeddings
print("Vector for 'dog':", model.wv["dog"])

# Find similar words
print("Most similar words to 'dog':", model.wv.most_similar("dog"))
