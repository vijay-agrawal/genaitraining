This folder contains Gen AI code for labs

Steps to setup:

1) Make sure you have Python 3.12.6 or 3.12.7 installed (not a newer version but only one of these 2 versions)
To test, you can open command prompt and type:

python -v


2) Open this folder "genai" in VS Code
3) Setup virtual environment:
Open terminal from VS Code and issue following commands

python -m venv venv
venv\scripts\activate

If a popup shows in VS Code asking you to set this as your default environment, click on "Yes"

4) pip install -r requirements.txt

5) Once successfully installed, test the installation by executing the following python codes:
You can execute them by clicking on the "Play" button on top right or from the terminal in VS Code

a) test_azure_openai.py
b) test_aws_bedrock.py


