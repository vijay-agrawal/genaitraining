import json
import requests
from openai import AzureOpenAI
from dotenv import load_dotenv
import sys
import os

def main():

 load_dotenv()
 

#creating an Azure OpenAI client
 client = AzureOpenAI(
    azure_endpoint = os.getenv("AZURE_OPENAI_ENDPOINT"), 
    api_key=os.getn,
    api_version=azure_config["api_version"]
    )
 functions=[
        {
            "name":"get_weather",
            "description":"Retrieve real-time weather information/data about a particular location/place",
            "parameters":{
                "type":"object",
                "properties":{
                    "location":{
                        "type":"string",
                        "description":"the exact location whose real-time weather is to be determined",
                    },
                    
                },
                "required":["location"]
            },
        },
         {
            "name":"get_latlong",
            "description":"Retrieve latitude and longitude information/data about a particular location/place",
            "parameters":{
                "type":"object",
                "properties":{
                    "location":{
                        "type":"string",
                        "description":"the exact location whose latitude and longitude is to be determined",
                    },
                    
                },
                "required":["location"]
            },
        }
    ] 

 
 initial_response = client.chat.completions.create(
    model="gpt-35-turbo",
    messages=[
        {"role": "system", "content": "You are a helpful assistant."},
        {"role": "user", "content": "How is the weather in Mumbai?"}
    ],
   functions=functions
 )

 print (initial_response)
 function_name = initial_response.choices[0].message.function_call.name
 function_arguments = json.loads(initial_response.choices[0].message.function_call.arguments)
 location= function_arguments['location']
 if(location):
    print(location)
    getattr(sys.modules[__name__], function_name)(location)

def get_weather(location):
    #calling open weather map API for information retrieval
    #fetching latitude and longitude of the specific location respectively
    print("Getting weather for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    # If SSL certificate issue, use verify=False
    response=requests.get(url, verify=False)
    print(response)
    get_response=response.json()
    latitude=get_response[0]['lat']
    longitude = get_response[0]['lon']

    url_final = "https://api.openweathermap.org/data/3.0/onecall?lat=" + str(latitude) + "&lon=" + \
        str(longitude) + "&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    final_response = requests.get(url_final, verify=False)
    final_response_json = final_response.json()
    weather=final_response_json['current']['weather'][0]['description'] + "\nHumidity: " + str(final_response_json['current']['humidity']) + "\nUV Index: " + str(final_response_json['current']['uvi'])
    print(weather)

def get_latlong(location):
    #calling open weather map API for information retrieval
    #fetching latitude and longitude of the specific location respectively
    print("Getting weather for: " + location)
    url = "http://api.openweathermap.org/geo/1.0/direct?q=" + location + "&limit=1&appid=" + os.getenv("OPENWEATHERMAP_API_KEY")
    # If SSL certificate issue, use verify=False
    response=requests.get(url, verify=False)
    print(response)
    get_response=response.json()
    latitude=get_response[0]['lat']
    longitude = get_response[0]['lon']

    print("latitude is ", latitude, "longitude is ", longitude)

if __name__ == "__main__":
    main()
 